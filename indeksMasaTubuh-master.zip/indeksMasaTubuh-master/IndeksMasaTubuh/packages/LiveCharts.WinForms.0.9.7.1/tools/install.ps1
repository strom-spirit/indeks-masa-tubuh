param($installPath, $toolsPath, $package, $project)

$DTE.ItemOperations.Navigate("https://lvcharts.net/thanks/wpf")