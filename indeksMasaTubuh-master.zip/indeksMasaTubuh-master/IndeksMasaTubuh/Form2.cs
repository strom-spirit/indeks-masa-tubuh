﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndeksMasaTubuh
{
    public partial class Form_login : MaterialSkin.Controls.MaterialForm
    {
        private string myValue;
        public string returnValue
        {
            get { return myValue; }
            set { myValue = value; }
        }
        public string selected_dialog_option;
        public Form_login()
        {
            InitializeComponent();            
        }
        private void authenticate()
        {
            if (textBox_Username.Text == "admin" && textBox_Password.Text == "123456")
            {
                myValue = "success";
                MessageBox.Show("authentication success");
                this.Close();
            }
            else
            {
                myValue = "failed";
                MessageBox.Show("authentication failed");
                this.Close();
            }
        }
        private void button_Continue_Click(object sender, EventArgs e)
        {
            authenticate();
        }
        private void button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }    
        private void textBox_Password_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                authenticate();
            }
        }
        private void textBox_Username_Enter(object sender, EventArgs e)
        {
            if(textBox_Username.Text=="username")
            {
                textBox_Username.Text = "";
                textBox_Username.ForeColor = Color.Black;
            }
        }
        private void textBox_Username_Leave(object sender, EventArgs e)
        {
            if (textBox_Username.Text == "")
            {
                textBox_Username.Text = "username";
                textBox_Username.ForeColor = Color.Silver;
            }
        }
        private void textBox_Password_Enter(object sender, EventArgs e)
        {
            if (textBox_Password.Text == "password")
            {
                textBox_Password.PasswordChar = '#';
                textBox_Password.Text = "";
                textBox_Password.ForeColor = Color.Black;
            }
        }
        private void textBox_Password_Leave(object sender, EventArgs e)
        {
            if (textBox_Password.Text == "")
            {
                textBox_Password.PasswordChar = (char)0;
                textBox_Password.Text = "password";
                textBox_Password.ForeColor = Color.Silver;
            }
        }

        private void button_loginAsUser_Click(object sender, EventArgs e)
        {
            myValue = "loginAsUser";
        }
    }
}
