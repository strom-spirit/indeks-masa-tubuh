﻿//#define offline
#define online
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO.Ports;
using System.Windows.Forms;
using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;
using MySql.Data.MySqlClient;
using System.Drawing.Printing;
using System.Timers;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Reflection;
//using ClosedXML.Excel; 

//using MColor = System.Windows.Media.Brush;
//using DColor = System.Drawing.Color;

namespace IndeksMasaTubuh
{
    public partial class Form1 : Form
    {
        string dataBaseSource = "offline";
        //static string mySqlConnectionString = "datasource=srv24.niagahoster.com; port=3306; username=u8900870_imtUser; password=240494ti; " +
        //                                      "database=u8900870_IMT; SslMode=none; convert zero datetime=True";
        //static string mySqlConnectionString = "datasource=srv30.niagahoster.com; port=3306; username=u3372604_imt_user; password=imt123; " +
        //                                      "database=u3372604_imt; SslMode=none; convert zero datetime=True";

        static string mySqlConnectionString = "datasource=localhost; port=3306; username=root; password=; " +
                                              "database=jadi_db_imt; SslMode=none; convert zero datetime=True";
        String tableName_DataPublic = "data_public";
        String tableName_DataIndividual = "data_individual";

        /*
        static string mySqlConnectionString = "datasource=sql144.main-hosting.eu; port=3306; username=u151020339_uimt; password=imt123; " +
                                              "database=u151020339_imt; SslMode=none; convert zero datetime=True";
        String tableName_DataPublic = "`u151020339_imt`.`data_public`";
        String tableName_DataIndividual = "`u151020339_imt`.`data_individual`";
        */
        
        
        

        


        MySqlConnection databaseConnection = new MySqlConnection(mySqlConnectionString);
        DataSet db_data;
        MySqlDataAdapter db_select;
        MySqlCommand SQL_cmd;

        //String tableName_DataPublic = "`u3372604_imt`.`data_public`";
        //String tableName_DataIndividual = "`u3372604_imt`.`data_individual`";


        String tableName_DataPublic_root = "data_public";
        String tableName_DataIndividual_root = "data_individual";

        Bitmap bmp;
        string RxStr;


        string theDate;
        string theTime;

        CancellationTokenSource tokenSource = new CancellationTokenSource();

        public string selected_NRP { get; set; }
        string loginAs = "";

        public Form1()
        {
            InitializeComponent();

            this.aGauge_IMT_berat_badan.Center = new System.Drawing.Point(aGauge_IMT_berat_badan.Size.Width / 2, aGauge_IMT_berat_badan.Size.Height / 2);
            this.aGauge_IMT_IMT.Center = new System.Drawing.Point(aGauge_IMT_IMT.Size.Width / 2, aGauge_IMT_IMT.Size.Height / 2);

            disp_tinggi_badan_setup();
            //disp_berat_badan(75);

            //disp_IMT(175,65);
            create_IMT_DataTable("SELECT * FROM " + tableName_DataPublic, databaseConnection);
            create_Individual_DataTable_and_DataChart("SELECT * FROM " + tableName_DataIndividual, databaseConnection);

            //SELECT `NRP`, `Nama`, `Tanggal Terakhir`, `Tinggi Badan(cm)`, `Berat Badan(Kg)`, `IMT`, `Status`, `Berat Yang Harus Diubah(Kg)` FROM `data_public`
            //create_Individual_DataTable("SELECT `NRP`, `Nama`, `Tanggal Pengambilan`, `Tinggi Badan(cm)`, `Berat Badan(Kg)`, " +
            //                            "`IMT`, `Status`, `Berat Yang Harus Diubah(Kg)` FROM " + 
            //                            tableName_DataIndividual_root, databaseConnection);
            disp_DataChart_Init();
            create_Solusi_DataTable();
            delete_DataPublic_Button_insert();
            delete_DataIndividual_Button_insert();

            theTime = DateTime.Now.ToString("HH:mm:ss");
            theDate = dateTimePicker_IMT.Value.ToString("yyyy-MM-dd");
            textBox_IMT_Status.Text = theDate;

            create_IMT_DataTable("SELECT * FROM " + tableName_DataPublic, databaseConnection);

            comboBox_BaudRate.SelectedIndex = 1;
            refreshBaud();
            //default selected value 9600
            this.Show();
            admin_login();
        }

        async Task PutTaskDelay()
        {
            try
            {
                await Task.Delay(5000, tokenSource.Token);
            }
            catch (TaskCanceledException ex)
            {

            }
            catch (Exception ex)
            {

            }
        }

        private string authenticate_admin()
        {
            Form_login login = new Form_login();
            login.ShowDialog();
            return login.returnValue;
        }
        private void admin_login()
        {
            if (authenticate_admin() == "success")
            {
                loginAs = "admin";
                MessageBox.Show("loged-in as admin");
                button_login.Text = "Logout";
            }
            else 
            {
                loginAs = "user";
                MessageBox.Show("loged-in as user");
            }
        }
        private void button_login_Click(object sender, EventArgs e)
        {
            if (button_login.Text == "Login Admin") admin_login();
            else
            {
                MessageBoxButtons buttons = MessageBoxButtons.OKCancel;
                DialogResult dialogResult;

                string message = "Logout as Admin ?";
                dialogResult = MessageBox.Show (message, "" ,buttons);
                if (dialogResult == DialogResult.OK)
                {
                    loginAs = "user";
                    MessageBox.Show("Admin Logout, Login as User");
                    button_login.Text = "Login Admin";
                }
                else
                {
                    return;
                }
                
            }
        }

        /***************************************************** Serial Control *****************************************************/
        private void refreshBaud()
        {
            comboBox_ComPort.Items.Clear();
            comboBox_ComPort.Text = "";
            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {
                comboBox_ComPort.Items.Add(port);
            }
        }
        private void com_refresh_Click(object sender, EventArgs e)
        {
            refreshBaud();
        }
        private void BaudRate_select(object sender, EventArgs e)
        {
            try
            {
                serialPort.PortName = comboBox_ComPort.Items[comboBox_ComPort.SelectedIndex].ToString();
            }
            catch { comboBox_ComPort.Items.Add("error bro"); }
        }
        private void button_ComOpenClose_Click(object sender, EventArgs e)
        {
            this.Invoke(new EventHandler(BaudRate_select));
            if (serialPort.IsOpen == false)
            {

                try
                {
                    //serialPort1.BaudRate = Convert.ToInt16(BaudRate.Text);
                    //serialPort.BaudRate = Convert.ToInt32(comboBox_BaudRate.Text);
                    //serialPort.BaudRate = 115200;
                    serialPort.BaudRate = Convert.ToInt32(comboBox_BaudRate.Items[comboBox_BaudRate.SelectedIndex].ToString());
                    serialPort.Open();
                    button_ComOpenClose.Text = "Disconnect";
                    //Draw.Clear(Color.White);
                    //draw_cart();

                }
                catch
                {
                    MessageBox.Show("port unavailable");
                }
            }
            else
            {
                serialPort.Write("!");
                serialPort.DiscardInBuffer();
                //Draw.Clear(Color.White);
                while (serialPort.IsOpen == true)
                {
                    try
                    {
                        serialPort.Close();
                    }
                    catch { };
                }
                button_ComOpenClose.Text = "Connect";
            }
        }
        /***************************************************** End of Serial control *****************************************************/



        /***************************************************** Ambil-data Sction *****************************************************/        
        private void aGauge_berat_setup()
        {
            System.Windows.Forms.AGaugeRange aGaugeRange17 = new System.Windows.Forms.AGaugeRange();
            aGaugeRange17.Color = System.Drawing.Color.Lime;
            //aGaugeRange17.StartValue = Convert.ToSingle(18 * Math.Pow(tinggi, 2));
            //aGaugeRange17.EndValue = Convert.ToSingle(23 * Math.Pow(tinggi, 2));
            aGaugeRange17.InnerRadius = 125;
            aGaugeRange17.InRange = false;
            aGaugeRange17.Name = "GaugeRange34";
            aGaugeRange17.OuterRadius = 145;
            this.aGauge_IMT_berat_badan.GaugeRanges.Add(aGaugeRange17);
        }
        private void disp_tinggi_badan_setup()
        {
            System.Drawing.Color color_drawing_ColumnBar = ColorTranslator.FromHtml("#000000");
            System.Windows.Media.Color color_axisLabel = System.Windows.Media.Color.FromRgb(color_drawing_ColumnBar.R, color_drawing_ColumnBar.G, color_drawing_ColumnBar.B);

            color_drawing_ColumnBar = ColorTranslator.FromHtml("#00FF00");
            System.Windows.Media.Color color_columnBar =
                System.Windows.Media.Color.FromRgb(
                    color_drawing_ColumnBar.R, color_drawing_ColumnBar.G, color_drawing_ColumnBar.B);

            cartesianChart_IMT_tinggi.Series = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = "Tinggi",
                    Values = new ChartValues<double> {0},
                    Fill=new System.Windows.Media.SolidColorBrush(color_columnBar),
                    MinWidth = 20,
                    Width = 100,
                }

            };
            

            /* this line adds new series
            cartesianChart1.Series.Add(new ColumnSeries
            {
                Title = "2016",
                Values = new ChartValues<double> { 11, 56, 42 }
            });
            */

            //artesianChart_IMT_tinggi.Series[0].Values.Add(48d);

            cartesianChart_IMT_tinggi.AxisX.Add(new Axis
            {
                Title = "",
                Labels = new[] { "" },
                FontSize = 12,
                Foreground = new System.Windows.Media.SolidColorBrush(color_axisLabel),
            });
            

            cartesianChart_IMT_tinggi.AxisY.Add(new Axis
            {
                Title = "tinggi badan",
                LabelFormatter = value => value.ToString("N"),
                FontSize = 12,
                MaxValue = 250,
                MinValue = 0,
                MinWidth = 15,
                Foreground = new System.Windows.Media.SolidColorBrush(color_axisLabel),
            });
            

        }
        private void disp_tinggi_badan(string nama, int tinggi)
        {
            cartesianChart_IMT_tinggi.Series[0].Erase(true);

            cartesianChart_IMT_tinggi.Series[0].Values = new ChartValues<double> {tinggi};
            cartesianChart_IMT_tinggi.AxisX[0].Labels = new []{nama};
            
            textBox_IMT_tinggi.Text = tinggi.ToString();
            textBox_IMT_tinggi.AppendText(" cm");
        }
        private void disp_berat_badan(double berat)
        {
            aGauge_IMT_berat_badan.Value = Convert.ToSingle(berat);
            textBox_IMT_berat.Text = berat.ToString("f2");
            textBox_IMT_berat.AppendText(" Kg");
        }
        private void disp_IMT(double tinggi, double berat)
        {
            disp_tinggi_badan(textBox_IMT_Nama.Text, Convert.ToInt32(tinggi));      
            disp_berat_badan(berat);

            tinggi = tinggi / 100;

            double imt = berat / Math.Pow(tinggi,2);

            textBox_IMT_value.Text = imt.ToString("f2");
            aGauge_IMT_IMT.Value = Convert.ToSingle(imt);
            
            aGauge_IMT_berat_badan.GaugeRanges[0].StartValue = Convert.ToSingle(18 * Math.Pow(tinggi, 2));
            aGauge_IMT_berat_badan.GaugeRanges[0].EndValue = Convert.ToSingle(23 * Math.Pow(tinggi, 2));

            double beratDiubah;

            if (imt > 25) label_beratDiubah.Text = "Berat badan yang Harus diturunkan";
            else if (imt < 18) label_beratDiubah.Text = "Berat badan yang Harus dinaikkan";

            textBox_IMT_toBeratIdeal.Text = "";

            if (imt < 18 || imt>25)
            {
                beratDiubah = 21 * Math.Pow(tinggi, 2) - berat;
                //beratDiubah = Math.Abs(beratDiubah);

                if(beratDiubah>0)
                {
                    textBox_IMT_toBeratIdeal.AppendText("+");
                }
                textBox_IMT_toBeratIdeal.AppendText(beratDiubah.ToString("f2")); 
                textBox_IMT_toBeratIdeal.AppendText(" Kg");
            }

            if (imt < 18.5) textBox_IMT_Status.Text = "Underweight";
            else if (imt >= 18.5 && imt < 25) textBox_IMT_Status.Text = "Ideal";
            else if (imt >= 25 && imt < 30) textBox_IMT_Status.Text = "Overweight";
            else if (imt >= 30) textBox_IMT_Status.Text = "Obesitas";
        }
        private void querryExecute(string querry)
        {
            SQL_cmd = new MySqlCommand(querry, databaseConnection);
            SQL_cmd.CommandTimeout = 60;
            try
            {
                databaseConnection.Open();
                MySqlDataReader reader = SQL_cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    MessageBox.Show("see console");
                    while (reader.Read())
                    {
                        Console.WriteLine(reader.GetString(0) + "." + reader.GetString(1) + "." + reader.GetString(3) + "." + reader.GetString(3) + ".");
                    }
                }
                else
                {
                    MessageBox.Show("succsfull querry");
                }
                databaseConnection.Close();
            }
            catch (Exception exc)
            {
                MessageBox.Show("querry error: " + exc.Message);
            }
        }
        private void insert_dataPublic()
        {
            string querry = "INSERT INTO "+ tableName_DataPublic +  
                            " SELECT* FROM " + tableName_DataIndividual + " WHERE `NRP` = " + textBox_IMT_NRP.Text;

            querryExecute(querry);

        }
        private void update_dataPublic()
        {
            /*
            string querry = "UPDATE " + tableName_DataPublic + " SET " +
                             "`Nama` = '" + textBox_IMT_Nama.Text + "'," +
                             "`Pangkat` = '" + comboBox_IMT_Pangkat.Text + "'," +
                             "`Korps` = '" + textBox_IMT_Korps.Text + "'," +
                             "`Tanggal Terakhir` = '" + DateTime.Today.ToString("yyyy-MM-dd") + "', " +
                             "`Tinggi Badan(cm)` = '" + textBox_IMT_tinggi.Text + "', " +
                             "`Berat Badan(Kg)` = '" + textBox_IMT_berat.Text + "', " +
                             "`IMT` = '" + textBox_IMT_value.Text + "', " +
                             "`Status` = '" + textBox_IMT_Status.Text + "', " +
                             "`Berat Yang Harus Diubah(Kg)` = '" + textBox_IMT_toBeratIdeal.Text + "' " +
                             "WHERE " + tableName_DataPublic_root + ".`NRP` = " + textBox_IMT_NRP.Text;
            */

            db_select = new MySqlDataAdapter("SELECT * FROM " + tableName_DataIndividual + " WHERE NRP = " + textBox_IMT_NRP.Text + 
                                             " ORDER BY `Tanggal Pengambilan` DESC LIMIT 1", databaseConnection);
            db_data = new System.Data.DataSet();
            db_select.Fill(db_data);

            dataGridView_DataIndividual.DataSource = db_data.Tables[0];

            //textBox_DataIndividual_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();
            DateTime getDate = DateTime.Parse(db_data.Tables[0].Rows[0]["Tanggal Pengambilan"].ToString());

            string querry = "UPDATE " + tableName_DataPublic + " SET " +
                             "`Nama` = '" + db_data.Tables[0].Rows[0]["Nama"].ToString() + "'," +
                             "`Pangkat` = '" + db_data.Tables[0].Rows[0]["Pangkat"].ToString() + "'," +
                             "`Korps` = '" + db_data.Tables[0].Rows[0]["Korps"].ToString() + "'," +
                             "`Tanggal Terakhir` = '" + getDate.ToString("yyyy-MM-dd HH:mm:ss") + "', " +
                             "`Tinggi Badan(cm)` = '" + db_data.Tables[0].Rows[0]["Tinggi Badan(cm)"].ToString() + "', " +
                             "`Berat Badan(Kg)` = '" + db_data.Tables[0].Rows[0]["Berat Badan(Kg)"].ToString() + "', " +
                             "`IMT` = '" + db_data.Tables[0].Rows[0]["IMT"].ToString() + "', " +
                             "`Status` = '" + db_data.Tables[0].Rows[0]["Status"].ToString() + "', " +
                             "`Berat Yang Harus Diubah(Kg)` = '" + db_data.Tables[0].Rows[0]["Berat Yang Harus Diubah(Kg)"].ToString() + "' " +
                             "WHERE " + tableName_DataPublic_root + ".`NRP` = " + textBox_IMT_NRP.Text;

            querryExecute(querry);
            //databaseConnection.Close();
        }
        private void insert_dataIndividual()
        {
            string querry = "INSERT INTO " + tableName_DataIndividual + " (`NRP`, `Nama`, `Pangkat`, `Korps`, `Tanggal Pengambilan`, `Tinggi Badan(cm)`," +
                                                                     " `Berat Badan(Kg)`, `IMT`, `Status`,`Berat Yang Harus Diubah(Kg)`) " +
                            "VALUES(" +
                            "'" + textBox_IMT_NRP.Text + "'," +
                            "'" + textBox_IMT_Nama.Text + "'," +
                            "'" + comboBox_IMT_Pangkat.Text + "'," +
                            "'" + textBox_IMT_Korps.Text + "'," +
                            "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'," +
                            "'" + textBox_IMT_tinggi.Text + "'," +
                            "'" + textBox_IMT_berat.Text + "'," +
                            "'" + textBox_IMT_value.Text + "'," +
                            "'" + textBox_IMT_Status.Text + "'," +
                            "'" + textBox_IMT_toBeratIdeal.Text +
                            "')";

            querryExecute(querry);
        }
        private void save_IMT()
        {
            if (loginAs == "admin")
            {
                db_select = new MySqlDataAdapter("SELECT * FROM " + tableName_DataPublic + " WHERE NRP like '%" + textBox_IMT_NRP.Text + "%'", databaseConnection);
                db_data = new System.Data.DataSet();
                db_select.Fill(db_data);
                int rowcount = db_data.Tables[0].Rows.Count;
                string querry;

                MessageBoxButtons buttons = MessageBoxButtons.OKCancel;
                DialogResult dialogResult;

                if (rowcount == 0) //INSERT
                {
                    string message = "Data dengan NRP: " + textBox_IMT_NRP.Text + " belum ada dalam database. Insert data baru?";
                    string caption = "";

                    // Displays the MessageBox.

                    dialogResult = MessageBox.Show(message, caption, buttons);

                    if (dialogResult == System.Windows.Forms.DialogResult.OK)
                    {
                        insert_dataIndividual();
                        insert_dataPublic();
                    }
                    else if (dialogResult == System.Windows.Forms.DialogResult.Cancel)
                    {
                        return;
                    }
                }

                else //UPDATE
                {
                    string message = "Data dengan NRP: " + textBox_IMT_NRP.Text + " sudah ada dalam database. Update data lama?";
                    string caption = "";
                    // Displays the MessageBox.

                    dialogResult = MessageBox.Show(message, caption, buttons);

                    if (dialogResult == DialogResult.OK)
                    {
                        insert_dataIndividual();
                        update_dataPublic();
                    }
                    else if (dialogResult == DialogResult.Cancel)
                    {
                        return;
                    }
                }
            }
            else
            {
                MessageBox.Show("you are not admin, login first!!!");
                admin_login();
            }
        }
        //////////////////////////////////////////////////// event handler//////////////////////////////////////////////////
        private void textBox_IMT_NRP_LeaveEvent(object sender, EventArgs e)
        {
            try
            {
                db_select = new MySqlDataAdapter("SELECT * FROM " + tableName_DataPublic + " WHERE NRP like '%" + textBox_IMT_NRP.Text + "%'", databaseConnection);
                db_data = new System.Data.DataSet();
                db_select.Fill(db_data);

                textBox_IMT_NRP.Text = db_data.Tables[0].Rows[0]["NRP"].ToString();
                textBox_IMT_Nama.Text = db_data.Tables[0].Rows[0]["Nama"].ToString();
                textBox_IMT_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();
                comboBox_IMT_Pangkat.Text = db_data.Tables[0].Rows[0]["Pangkat"].ToString();

                disp_IMT(Convert.ToDouble(db_data.Tables[0].Rows[0]["Tinggi Badan(cm)"]), Convert.ToDouble(db_data.Tables[0].Rows[0]["Berat Badan(Kg)"]));
            }
            catch 
            {
                //MessageBox.Show("querry error: " + exc.Message);
            }

        }
        private void button_GetData_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen == true)
            {
                serialPort.Write("#");
            }
            else
            {
                MessageBox.Show("Error, Sensor Disconnected");
                Random random = new Random();

                //generate random for data dummy

                int tinggi_orang = random.Next(160, 210); // random between 160 to 210
                double berat_orang = random.Next(50, 100) + random.NextDouble(); // random between 50.0 to 100.9


                textBox_IMT_tinggi.Text = tinggi_orang.ToString();
                textBox_IMT_berat.Text = berat_orang.ToString();

                disp_IMT(tinggi_orang, berat_orang);
            }
            //Random random = new Random();

            //generate random for data dummy
            //int tinggi_orang = random.Next(160, 210); // random between 160 to 210
            //double berat_orang = random.Next(50, 100) + random.NextDouble(); // random between 50.0 to 100.9


            //textBox_IMT_tinggi.Text = tinggi_orang.ToString();
            //textBox_IMT_berat.Text = berat_orang.ToString();

            //disp_IMT(tinggi_orang, berat_orang);
        }
        private void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (serialPort.IsOpen == true) RxStr = serialPort.ReadExisting();
            this.Invoke(new EventHandler(parseSerial));
            //int r = 0;
            //textBox1.Text = RxStr;
        }
        private void parseSerial(object sender, EventArgs e)
        {
            textBox1.Text = RxStr;

            int parseWeight = Convert.ToInt16(RxStr.Substring(RxStr.IndexOf('!') + 1, 4));
            int parseHeight = Convert.ToInt16(RxStr.Substring(RxStr.IndexOf('@') + 1, 3));

            int tinggi_orang = parseHeight;
            double berat_orang = parseWeight / 10.0;

            textBox_IMT_tinggi.Text = tinggi_orang.ToString();
            textBox_IMT_berat.Text = berat_orang.ToString();

            disp_IMT(tinggi_orang, berat_orang);
        }
        private void button_IMT_simpan_Click(object sender, EventArgs e) //save to database
        {
            save_IMT();
        }
        private void button_IMT_Hapus_Click(object sender, EventArgs e)
        {
            textBox_IMT_NRP.Text = "";
            textBox_IMT_Nama.Text = "";
            textBox_IMT_Korps.Text = "";
            //textBox_IMT_tinggi.Text = "";
            //textBox_IMT_.Text = "";
            comboBox_IMT_Pangkat.Text = "";

            disp_IMT(0, 0);
            //MessageBox.Show("Authentication "+authenticate_admin());
        }
        private void button_IMT_print_Click(object sender, EventArgs e)
        {
            //printDocument_IMT.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("custom", 1380, 720);
            groupBox3.BackColor = Color.White;
            groupBox_IMT_Gauge.BackColor = Color.White;
            aGauge_IMT_IMT.BackColor = Color.White;
            aGauge_IMT_berat_badan.BackColor = Color.White;
            cartesianChart_IMT_tinggi.BackColor = Color.White;
            this.Refresh();

            //Thread.Sleep(5000);

            Panel panel = new Panel();
            this.Controls.Add(panel);
            Graphics grp = panel.CreateGraphics();
            Size formSize = this.ClientSize;
            formSize.Height -= 100;
            formSize.Width  -= 0;
            bmp = new Bitmap(formSize.Width, formSize.Height, grp);
            grp = Graphics.FromImage(bmp);
            Point panelLocation = PointToScreen(panel.Location);
            grp.CopyFromScreen(panelLocation.X-20, panelLocation.Y+50, 0, 0, formSize);

            //printDocument_IMT.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Width + 50, formSize.Height - 10);
            printDocument_IMT.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Height-10, formSize.Width-0);
            printDocument_IMT.PrinterSettings.PrinterName = "Foxit Reader PDF Printer";

            printPreviewDialog_IMT.Document = printDocument_IMT;
            ((Form)printPreviewDialog_IMT).WindowState = FormWindowState.Maximized;

            //printDocument_IMT.Print();
            
            printPreviewDialog_IMT.ShowDialog();
            groupBox3.BackColor = Color.RoyalBlue;
            groupBox_IMT_Gauge.BackColor = Color.RoyalBlue;
            aGauge_IMT_IMT.BackColor = Color.RoyalBlue;
            aGauge_IMT_berat_badan.BackColor = Color.RoyalBlue;
            cartesianChart_IMT_tinggi.BackColor = Color.RoyalBlue;
            this.Refresh();
        }
        private void printDocument_IMT_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Size formSize = this.ClientSize;
            Rectangle pagearea = e.PageBounds;
            e.Graphics.RotateTransform(-90);
            e.Graphics.DrawImage(bmp, -(formSize.Width+50), 0);
            //
            //e.Graphics.DrawImage(bmp, 0, 0);
        }
        /***************************************************** end of ambil-data-tab section *****************************************************/



        /*****************************************************   DATA TABLE Section   *****************************************************/
        private void delete_DataPublic_Button_insert()
        {
            DataGridViewButtonColumn button_deleteRow = new DataGridViewButtonColumn();
            button_deleteRow.Name = "deleteRow";
            button_deleteRow.Text = "Delete";
            button_deleteRow.HeaderText = "";
            button_deleteRow.UseColumnTextForButtonValue = true;
            try
            {
                dataGridView_DataTbaleIMT_Public.Columns.Insert(10, button_deleteRow);
            }
            catch { }
            //dataGridView_DataTbaleIMT_Public.Columns.Add(button_deleteRow);
            
            //dataGridView_DataTbaleIMT_Public.Columns[button_deleteRow.Name]. = 10;
        }
        private void delete_DataIndividual_Button_insert()
        {
            DataGridViewButtonColumn button_deleteRow = new DataGridViewButtonColumn();
            button_deleteRow.Name = "deleteRow";
            button_deleteRow.Text = "Delete";
            button_deleteRow.HeaderText = "";
            button_deleteRow.UseColumnTextForButtonValue = true;
            try
            {
                dataGridView_DataIndividual.Columns.Insert(10, button_deleteRow);
            }
            catch { }
            //dataGridView_DataTbaleIMT_Public.Columns.Add(button_deleteRow);

            //dataGridView_DataTbaleIMT_Public.Columns[button_deleteRow.Name]. = 10;
        }
        private void create_IMT_DataTable(string sqlCmd,MySqlConnection sqlCon)
        {
            try
            {
                db_select = new MySqlDataAdapter(sqlCmd, sqlCon);
                db_data = new System.Data.DataSet();
                db_select.Fill(db_data, tableName_DataPublic);
   
                dataGridView_DataTbaleIMT_Public.DataSource = db_data.Tables[0];
                this.dataGridView_DataTbaleIMT_Public.Columns[4].DefaultCellStyle.Format = "dd/MM/yyyy HH:mm:ss";

                foreach (DataRow theRow in db_data.Tables[0].Rows)
                {
                    Console.WriteLine(theRow["NRP"] + "\t" + theRow["Nama"]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("querry error" + e.Message);
            }
        }
        private void tabData_enterEvent(object sender, EventArgs e)
        {
            
        }
        private void dataGridView_DataTbaleIMT_Public_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            string strNRP_nama = dataGridView_DataTbaleIMT_Public.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            //textBox_DataTable_search.Text = "double clicked ";
            //textBox_DataTable_search.AppendText(str);
            tabControl1.SelectedTab = tab_DataIndividual;

            create_Individual_DataTable_and_DataChart("SELECT * FROM " + tableName_DataIndividual + " WHERE NRP like '%" + strNRP_nama + "%'" +
                                        "OR Nama like '%" + strNRP_nama + "%' ORDER BY `Tanggal Pengambilan` DESC"
                                        , databaseConnection);

            //disp_DataChart();
        }
        private void dataGridview_DataTableIMT_Public_DeleteButtonClick(object sender, DataGridViewCellEventArgs e)
        {    
            if (e.ColumnIndex == 0)
            {
                if(loginAs=="admin")
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OKCancel;
                    DialogResult dialogResult;
                    string strNRP = dataGridView_DataTbaleIMT_Public.Rows[e.RowIndex].Cells["NRP"].Value.ToString();

                    string message = "Hapus semua entry Data NRP: " + strNRP + "?";
                    string caption = "Hapus Entry Data";
                    dialogResult = MessageBox.Show(message, caption, buttons);

                    Form_login login = new Form_login();
                    login.Show();

                    if (dialogResult == System.Windows.Forms.DialogResult.OK)
                    {
                        //DELETE FROM `data_public` WHERE `data_public`.`NRP` = 110121003
                        string querry = "DELETE FROM `" + tableName_DataPublic_root +
                                        "` WHERE `" + tableName_DataPublic_root + "`.`NRP` = " + strNRP;

                        querryExecute(querry);

                        querry = "DELETE FROM `" + tableName_DataIndividual_root +
                                        "` WHERE `" + tableName_DataIndividual_root + "`.`NRP` = " + strNRP;

                        querryExecute(querry);

                    }
                    else if (dialogResult == System.Windows.Forms.DialogResult.Cancel)
                    {
                        return;
                    }

                    create_IMT_DataTable("SELECT * FROM " + tableName_DataPublic, databaseConnection);
                    create_Individual_DataTable_and_DataChart("SELECT * FROM " + tableName_DataIndividual, databaseConnection);
                }
                else
                {
                    MessageBox.Show("you are not admin, you are not allowed to delete this data");
                    return;
                }

            }
            else
            {
                return;
            }
        }
        private void textBox_DataTable_Search_TextChanged(object sender, EventArgs e)
        {
            db_select = new MySqlDataAdapter("SELECT * FROM " + tableName_DataPublic + " WHERE NRP like '%" + textBox_DataTable_search.Text + "%'" +
                                             "OR Nama like '%" + textBox_DataTable_search.Text + "%'" +
                                             "OR Korps like '%" + textBox_DataTable_search.Text + "%'" +
                                             "OR Pangkat like '%" + textBox_DataTable_search.Text + "%'" +
                                             "OR Status like '%" + textBox_DataTable_search.Text + "%'"
                                             , databaseConnection);

            db_data = new System.Data.DataSet();
            db_select.Fill(db_data);

            dataGridView_DataTbaleIMT_Public.DataSource = db_data.Tables[0];
        }
        private void button_DataTable_Print_Click(object sender, EventArgs e)
        {
            Panel panel = new Panel();
            this.Controls.Add(panel);
            Graphics grp = panel.CreateGraphics();
            Size formSize = this.ClientSize;
            bmp = new Bitmap(formSize.Width, formSize.Height, grp);
            grp = Graphics.FromImage(bmp);
            Point panelLocation = PointToScreen(panel.Location);
            grp.CopyFromScreen(panelLocation.X, panelLocation.Y, 0, 0, formSize);

            //printDocument_DataTable.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Width + 50, formSize.Height - 10);
            printDocument_DataTable.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Height-20, formSize.Width+20);
            printDocument_DataTable.PrinterSettings.PrinterName = "Foxit Reader PDF Printer";

            printPreviewDialog_DataTable.Document = printDocument_DataTable;
            ((Form)printPreviewDialog_DataTable).WindowState = FormWindowState.Maximized;

            //printDocument_IMT.Print();

            printPreviewDialog_DataTable.ShowDialog();
        }
        private void printDocument_DataTable_PrintPage(object sender, PrintPageEventArgs e)
        {
            Size formSize = this.ClientSize;
            Rectangle pagearea = e.PageBounds;
            e.Graphics.RotateTransform(-90);
            e.Graphics.DrawImage(bmp, -(formSize.Width+20), 0);
            //
            //e.Graphics.DrawImage(bmp, 0, 0);
        }
        private void copyAlltoClipboard()
        {
            dataGridView_DataTbaleIMT_Public.SelectAll();
            DataObject dataObj = dataGridView_DataTbaleIMT_Public.GetClipboardContent();
            if (dataObj != null)
                Clipboard.SetDataObject(dataObj);
        }
        private void buttonDataTableExport_Click(object sender, EventArgs e)
        {
            create_IMT_DataTable("SELECT * FROM " + tableName_DataPublic, databaseConnection);
        }
        /*****************************************************   end of DATA TABLE Section   *****************************************************/



        /****************************************   Data Individual Section   ****************************************************/
        private void create_Individual_dataInfo(string nrp)
        {
            try
            {
                db_select = new MySqlDataAdapter("SELECT `NRP`, `Nama`,`Pangkat`,`Korps` FROM " + tableName_DataIndividual_root + 
                                                 " WHERE NRP=" + nrp + " ORDER BY `Tanggal Pengambilan` DESC", databaseConnection);
                db_data = new System.Data.DataSet();
                db_select.Fill(db_data, tableName_DataIndividual);
                
                textBox_DataIndividual_NRP.Text = db_data.Tables[0].Rows[0]["NRP"].ToString();
                textBox_DataIndividual_Nama.Text = db_data.Tables[0].Rows[0]["Nama"].ToString();
                textBox_DataIndividual_Pangkat.Text = db_data.Tables[0].Rows[0]["Pangkat"].ToString();
                textBox_DataIndividual_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();
            }
            catch (Exception e)
            {
                MessageBox.Show("querry error" + e.Message);
            }
        }
        private void create_Individual_DataTable_and_DataChart(string sqlCmd, MySqlConnection sqlCon)
        {
            //cartesianChart_DataChart.Series[0].Values.Add(45.6d);
            try
            {
                db_select = new MySqlDataAdapter(sqlCmd, sqlCon);
                db_data = new System.Data.DataSet();
                db_select.Fill(db_data, tableName_DataIndividual);
                dataGridView_DataIndividual.DataSource = db_data.Tables[0];
                dataGridView_DataIndividual.Columns["NRP"].Visible = false;
                dataGridView_DataIndividual.Columns["Nama"].Visible = false;
                dataGridView_DataIndividual.Columns["Pangkat"].Visible = false;
                dataGridView_DataIndividual.Columns["Korps"].Visible = false;
                this.dataGridView_DataIndividual.Columns[4].DefaultCellStyle.Format = "dd/MM/yyyy HH:mm:ss";
                

                //create_Individual_dataInfo(nrp);

                textBox_DataIndividual_NRP.Text = db_data.Tables[0].Rows[0]["NRP"].ToString();
                textBox_DataIndividual_Nama.Text = db_data.Tables[0].Rows[0]["Nama"].ToString();
                textBox_DataIndividual_Pangkat.Text = db_data.Tables[0].Rows[0]["Pangkat"].ToString();
                textBox_DataIndividual_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();

                textBox_DataChart_NRP.Text = db_data.Tables[0].Rows[0]["NRP"].ToString();
                textBox_DataChart_Nama.Text = db_data.Tables[0].Rows[0]["Nama"].ToString();
                textBox_DataChart_Pangkat.Text = db_data.Tables[0].Rows[0]["Pangkat"].ToString();
                textBox_DataChart_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();

                string getStatus = db_data.Tables[0].Rows[0]["Status"].ToString();

                cartesianChart_DataChart.Series = new SeriesCollection
                {
                    new LineSeries
                    {
                        Title = "Berat Badan",
                        Values = new ChartValues<DateTimePoint>
                        {

                        }
                    }
                };
                
                foreach (DataRow theRow in db_data.Tables[0].Rows)
                {
                    DateTime getDate = DateTime.Parse(theRow["Tanggal Pengambilan"].ToString());
                    Console.WriteLine(theRow["NRP"] + "\t" + theRow["Tanggal Pengambilan"] + "\t" + theRow["Berat Badan(Kg)"]);
                    //cartesianChart_DataChart.Series[0].Values.Add(Convert.ToDouble(theRow["IMT"]));
                    //values.Add(new DateTimePoint(getDate, Convert.ToDouble(theRow["IMT"])));
                    cartesianChart_DataChart.Series[0].Values.Add(new DateTimePoint(new System.DateTime(getDate.Year, getDate.Month, getDate.Day, 
                                                                                                        getDate.Hour, getDate.Minute, getDate.Second), 
                                                                                                        Convert.ToDouble(theRow["Berat Badan(Kg)"])));
                }

            }
            catch (Exception e)
            {
                if(e.Message!="There is no row at position 0.")
                {
                    MessageBox.Show("querry error " + e.Message + " Probably missing data set");
                }
                else
                {
                    //MessageBox.Show("querry error " + e.Message + " Probably missing data set");
                    return;
                }
                
            }
        }
        private void dataGridview_DataIndividual_DeleteButtonClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                if(loginAs == "admin" )
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OKCancel;
                    DialogResult dialogResult;
                    string strNRP = dataGridView_DataIndividual.Rows[e.RowIndex].Cells["NRP"].Value.ToString();
                    int numbRow = dataGridView_DataIndividual.RowCount;
                    DateTime getDate = DateTime.Parse(dataGridView_DataIndividual.Rows[e.RowIndex].Cells["Tanggal Pengambilan"].Value.ToString());

                    string message = "Hapus Data NRP: " + strNRP + ", tanggal entry : " + getDate.ToString() + "?";
                    string caption = "Hapus Entry Data";
                    dialogResult = MessageBox.Show(message, caption, buttons);

                    if (dialogResult == System.Windows.Forms.DialogResult.OK)
                    {
                        //DELETE FROM `data_public` WHERE `data_public`.`NRP` = 110121003
                        string querry = "DELETE FROM `" + tableName_DataIndividual_root +
                                        "` WHERE `" + tableName_DataIndividual_root + "`.`NRP` = " + strNRP +
                                        " AND `Tanggal Pengambilan` = \"" + getDate.ToString("yyyy-MM-dd HH:mm:ss") + "\" ";

                        querryExecute(querry);

                        if (numbRow == 1)
                        {
                            querry = "DELETE FROM `" + tableName_DataPublic_root +
                                     "` WHERE `" + tableName_DataPublic_root + "`.`NRP` = " + strNRP;

                            querryExecute(querry);
                        }
                    }
                    else if (dialogResult == System.Windows.Forms.DialogResult.Cancel)
                    {
                        return;
                    }
                    create_Individual_DataTable_and_DataChart("SELECT * FROM " + tableName_DataIndividual + " WHERE NRP like '%" + strNRP + "%'" +
                                                " ORDER BY `Tanggal Pengambilan` DESC", databaseConnection);

                    MessageBox.Show("Data telah dihapus ");
                }
                else
                {
                    MessageBox.Show("you are not admin, you are not allowed to delete this data");
                    return;
                }
                
            }
            else
            {
                return;
            }
        }
        private void textBox_DataIndividual_NRP_Leave(object sender, EventArgs e)
        {
            db_select = new MySqlDataAdapter("SELECT * FROM " + tableName_DataIndividual +
                                             " WHERE NRP like '%" + textBox_DataIndividual_NRP.Text + "%'" +
                                             " ORDER BY `Tanggal Pengambilan` DESC", databaseConnection);

            db_data = new System.Data.DataSet();
            db_select.Fill(db_data);
            dataGridView_DataIndividual.DataSource = db_data.Tables[0];

            try
            {
                //textBox_DataIndividual_NRP.Text = db_data.Tables[0].Rows[0]["NRP"].ToString();
                textBox_DataIndividual_Nama.Text = db_data.Tables[0].Rows[0]["Nama"].ToString();
                textBox_DataIndividual_Pangkat.Text = db_data.Tables[0].Rows[0]["Pangkat"].ToString();
                textBox_DataIndividual_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();
            }
            catch { }
        }
        private void textBox_DataIndividual_NRP_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                db_select = new MySqlDataAdapter("SELECT * FROM " + tableName_DataIndividual +
                                 " WHERE NRP like '%" + textBox_DataIndividual_NRP.Text + "%'" +
                                 " ORDER BY `Tanggal Pengambilan` DESC", databaseConnection);

                db_data = new System.Data.DataSet();
                db_select.Fill(db_data);
                dataGridView_DataIndividual.DataSource = db_data.Tables[0];

                try
                {
                    //textBox_DataIndividual_NRP.Text = db_data.Tables[0].Rows[0]["NRP"].ToString();
                    textBox_DataIndividual_Nama.Text = db_data.Tables[0].Rows[0]["Nama"].ToString();
                    textBox_DataIndividual_Pangkat.Text = db_data.Tables[0].Rows[0]["Pangkat"].ToString();
                    textBox_DataIndividual_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();
                }
                catch { }
            }

        }
        private void textBox_DataIndividual_Nama_Leave(object sender, EventArgs e)
        {
            db_select = new MySqlDataAdapter("SELECT * FROM " + tableName_DataIndividual +
                                             " WHERE Nama like '%" + textBox_DataIndividual_Nama.Text + "%'" +
                                             " ORDER BY `Tanggal Pengambilan` DESC", databaseConnection);

            db_data = new System.Data.DataSet();
            db_select.Fill(db_data);
            dataGridView_DataIndividual.DataSource = db_data.Tables[0];

            try
            {
                textBox_DataIndividual_NRP.Text = db_data.Tables[0].Rows[0]["NRP"].ToString();
                //textBox_DataIndividual_Nama.Text = db_data.Tables[0].Rows[0]["Nama"].ToString();
                textBox_DataIndividual_Pangkat.Text = db_data.Tables[0].Rows[0]["Pangkat"].ToString();
                textBox_DataIndividual_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();
            }
            catch { }
        }
        private void textBox_DataIndividual_Nama_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                db_select = new MySqlDataAdapter("SELECT * FROM " + tableName_DataIndividual +
                                             " WHERE Nama like '%" + textBox_DataIndividual_Nama.Text + "%'" +
                                             " ORDER BY `Tanggal Pengambilan` DESC", databaseConnection);

                db_data = new System.Data.DataSet();
                db_select.Fill(db_data);
                dataGridView_DataIndividual.DataSource = db_data.Tables[0];

                try
                {
                    textBox_DataIndividual_NRP.Text = db_data.Tables[0].Rows[0]["NRP"].ToString();
                    //textBox_DataIndividual_Nama.Text = db_data.Tables[0].Rows[0]["Nama"].ToString();
                    textBox_DataIndividual_Pangkat.Text = db_data.Tables[0].Rows[0]["Pangkat"].ToString();
                    textBox_DataIndividual_Korps.Text = db_data.Tables[0].Rows[0]["Korps"].ToString();
                }
                catch { }
            }

        }
        private void button_DataIndividual_Print_Click(object sender, EventArgs e)
        {
            Panel panel = new Panel();
            this.Controls.Add(panel);
            Graphics grp = panel.CreateGraphics();
            Size formSize = this.ClientSize;
            bmp = new Bitmap(formSize.Width, formSize.Height, grp);
            grp = Graphics.FromImage(bmp);
            Point panelLocation = PointToScreen(panel.Location);
            grp.CopyFromScreen(panelLocation.X, panelLocation.Y, 0, 0, formSize);

            //printDocument_DataTable.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Width + 50, formSize.Height - 10);
            printDocument_DataIndividual.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Height - 20, formSize.Width + 20);
            printDocument_DataIndividual.PrinterSettings.PrinterName = "Foxit Reader PDF Printer";

            printPreviewDialog_DataIndividual.Document = printDocument_DataIndividual;
            ((Form)printPreviewDialog_DataIndividual).WindowState = FormWindowState.Maximized;

            //printDocument_IMT.Print();

            printPreviewDialog_DataIndividual.ShowDialog();
        }
        private void printDocument_DataIndividual_PrintPage(object sender, PrintPageEventArgs e)
        {
            Size formSize = this.ClientSize;
            Rectangle pagearea = e.PageBounds;
            e.Graphics.RotateTransform(-90);
            e.Graphics.DrawImage(bmp, -(formSize.Width + 20), 0);
        }
  
        /*****************************************************   end of Data Individual Section   *****************************************************/



        /*****************************************************   Data chart Section   *****************************************************/
        private void disp_DataChart_Init()
        {
            System.Drawing.Color color_drawing = ColorTranslator.FromHtml("#000000");
            System.Windows.Media.Color color_axisLabel = System.Windows.Media.Color.FromRgb(color_drawing.R, color_drawing.G, color_drawing.B);

           //cartesianChart_DataChart.Series[0].Erase(true);

            cartesianChart_DataChart.Series = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Berat",
                    //Values = new ChartValues<double> {24.4, 26.8, 25.1, 22.6, 27.3}
                }
            };

            cartesianChart_DataChart.AxisX.Add(new Axis
            {
                Title = "Date",
                LabelFormatter = val => new System.DateTime((long)val).ToString("dd/MM/yyyy HH:mm:ss"),
                //Labels = new[] { "Jan", "Feb", "Mar", "Apr", "May" },
                FontSize = 14,
                Foreground = new System.Windows.Media.SolidColorBrush(color_axisLabel),
                Separator = new Separator
                {
                    StrokeThickness = 1,
                    StrokeDashArray = new System.Windows.Media.DoubleCollection(2),
                    Stroke = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(64, 79, 86))
                }
            });

            cartesianChart_DataChart.AxisY.Add(new Axis
            {
                Title = "Berat",
                LabelFormatter = value => value.ToString("f2"),
                FontSize = 14,
                MaxValue = 110,
                MinValue = 40,
                Foreground = new System.Windows.Media.SolidColorBrush(color_axisLabel),
                Separator = new Separator
                {
                    StrokeThickness = 1,
                    StrokeDashArray = new System.Windows.Media.DoubleCollection(2),
                    Stroke = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(64, 79, 86))
                }
            });
            
        }
        private void disp_DataChart()
        {
            System.Drawing.Color color_drawing = ColorTranslator.FromHtml("#000000");
            System.Windows.Media.Color color_axisLabel = System.Windows.Media.Color.FromRgb(color_drawing.R, color_drawing.G, color_drawing.B);

            //cartesianChart_DataChart.Series[0].Erase(true);

            cartesianChart_DataChart.Series = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Berat",
                    Values = new ChartValues<double>
                    {

                       
                    }
                }
                
            };
            cartesianChart_DataChart.Series[0].Values.Add(24.5);
        }
        private void button_DataChart_Print_Click(object sender, EventArgs e)
        {
            Panel panel = new Panel();
            this.Controls.Add(panel);
            Graphics grp = panel.CreateGraphics();
            Size formSize = this.ClientSize;
            bmp = new Bitmap(formSize.Width, formSize.Height, grp);
            grp = Graphics.FromImage(bmp);
            Point panelLocation = PointToScreen(panel.Location);
            grp.CopyFromScreen(panelLocation.X, panelLocation.Y, 0, 0, formSize);

            //printDocument_DataTable.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Width + 50, formSize.Height - 10);
            //printDocument_DataChart.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Height - 20, formSize.Width + 20);
            //printDocument_DataChart.PrinterSettings.PrinterName = "Foxit Reader PDF Printer";

            //printPreviewDialog_DataChart.Document = printDocument_DataChart;
            //((Form)printPreviewDialog_DataChart).WindowState = FormWindowState.Maximized;

            //printDocument_IMT.Print();

            //printPreviewDialog_DataChart.ShowDialog();
        }
        private void printDocument_DataChart_PrintPage(object sender, PrintPageEventArgs e)
        {
            Size formSize = this.ClientSize;
            Rectangle pagearea = e.PageBounds;
            e.Graphics.RotateTransform(-90);
            e.Graphics.DrawImage(bmp, -(formSize.Width + 20), 0);
        }
        /*****************************************************   end of Data chart Section   *****************************************************/



        /*****************************************************   Solusi Section   *****************************************************/
        private void create_Solusi_DataTable()
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("no");
            dt.Columns.Add("Jenis Olahraga");
            dt.Columns.Add("Waktu");
            dt.Columns.Add("Jumlah");
            dt.Columns.Add("Keterangan");


            dt.Rows.Add("1");
            dt.Rows.Add("2");
            dt.Rows.Add("3");
            dt.Rows.Add("4");
            dt.Rows.Add("5");

            dt.Rows[0]["Jenis Olahraga"] = "Lari";
            dt.Rows[1]["Jenis Olahraga"] = "Push Up";
            dt.Rows[2]["Jenis Olahraga"] = "Sit Up";
            dt.Rows[3]["Jenis Olahraga"] = ("Pull Up");
            dt.Rows[4]["Jenis Olahraga"] = "Renang";

            dataGridView_Solusi.DataSource = dt;
        }
        private void button_Solusi_Print_Click(object sender, EventArgs e)
        {
            Panel panel = new Panel();
            this.Controls.Add(panel);
            Graphics grp = panel.CreateGraphics();
            Size formSize = this.ClientSize;
            bmp = new Bitmap(formSize.Width, formSize.Height, grp);
            grp = Graphics.FromImage(bmp);
            Point panelLocation = PointToScreen(panel.Location);
            grp.CopyFromScreen(panelLocation.X, panelLocation.Y, 0, 0, formSize);

            //printDocument_DataTable.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Width + 50, formSize.Height - 10);
            printDocument_solusi.DefaultPageSettings.PaperSize = new PaperSize("custom", formSize.Height - 20, formSize.Width + 20);
            printDocument_solusi.PrinterSettings.PrinterName = "Foxit Reader PDF Printer";

            printPreviewDialog_solusi.Document = printDocument_solusi;
            ((Form)printPreviewDialog_solusi).WindowState = FormWindowState.Maximized;

            //printDocument_IMT.Print();

            printPreviewDialog_solusi.ShowDialog();
        }
        private void printDocument_solusi_PrintPage(object sender, PrintPageEventArgs e)
        {
            Size formSize = this.ClientSize;
            Rectangle pagearea = e.PageBounds;
            e.Graphics.RotateTransform(-90);
            e.Graphics.DrawImage(bmp, -(formSize.Width + 20), 0);
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox_IMT_berat_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox_IMT_berat_Leave(object sender, EventArgs e)
        {
            try
            {
                disp_IMT(Convert.ToDouble(textBox_IMT_tinggi.Text), Convert.ToDouble(textBox_IMT_berat.Text));
            }
            catch
            {
                MessageBox.Show("fields cannot be empty");
            }
        }

        private void dateTimePicker_IMT_ValueChanged(object sender, EventArgs e)
        {
            theDate = dateTimePicker_IMT.Value.ToString("yyyy-MM-dd ");
            theTime = DateTime.Now.ToString("HH:mm:ss");   
            textBox_IMT_Status.Text = theDate + theTime;
        }

        private void textBox_IMT_tinggi_Enter(object sender, EventArgs e)
        {
            textBox_IMT_tinggi.Text = "";
        }

        private void textBox_IMT_berat_Enter(object sender, EventArgs e)
        {
            textBox_IMT_berat.Text = "";
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.S))
            {
                if(textBox_IMT_berat.Text.Length==3)
                {
                    disp_IMT(Convert.ToDouble(textBox_IMT_tinggi.Text.Substring(0, 3)), Convert.ToDouble(textBox_IMT_berat.Text.Substring(0, 3)));
                }
                else disp_IMT(Convert.ToDouble(textBox_IMT_tinggi.Text.Substring(0, 3)), Convert.ToDouble(textBox_IMT_berat.Text.Substring(0, 2)));

                save_IMT();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        /*****************************************************   end of Solusi Section   *****************************************************/
    }
}
