﻿namespace IndeksMasaTubuh
{
    partial class Form_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Continue = new System.Windows.Forms.Button();
            this.textBox_Username = new System.Windows.Forms.TextBox();
            this.textBox_Password = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_loginAsUser = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_Continue
            // 
            this.button_Continue.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button_Continue.Location = new System.Drawing.Point(115, 142);
            this.button_Continue.Name = "button_Continue";
            this.button_Continue.Size = new System.Drawing.Size(75, 33);
            this.button_Continue.TabIndex = 3;
            this.button_Continue.Text = "login";
            this.button_Continue.UseVisualStyleBackColor = true;
            this.button_Continue.Click += new System.EventHandler(this.button_Continue_Click);
            // 
            // textBox_Username
            // 
            this.textBox_Username.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.textBox_Username.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.textBox_Username.Location = new System.Drawing.Point(115, 72);
            this.textBox_Username.Name = "textBox_Username";
            this.textBox_Username.Size = new System.Drawing.Size(156, 27);
            this.textBox_Username.TabIndex = 1;
            this.textBox_Username.Text = "username";
            this.textBox_Username.Enter += new System.EventHandler(this.textBox_Username_Enter);
            this.textBox_Username.Leave += new System.EventHandler(this.textBox_Username_Leave);
            // 
            // textBox_Password
            // 
            this.textBox_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.textBox_Password.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.textBox_Password.Location = new System.Drawing.Point(115, 107);
            this.textBox_Password.Name = "textBox_Password";
            this.textBox_Password.Size = new System.Drawing.Size(156, 27);
            this.textBox_Password.TabIndex = 2;
            this.textBox_Password.Text = "password";
            this.textBox_Password.Enter += new System.EventHandler(this.textBox_Password_Enter);
            this.textBox_Password.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_Password_KeyDown);
            this.textBox_Password.Leave += new System.EventHandler(this.textBox_Password_Leave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::IndeksMasaTubuh.Properties.Resources.loginkey_transparent;
            this.pictureBox1.Location = new System.Drawing.Point(3, 72);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // button_loginAsUser
            // 
            this.button_loginAsUser.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button_loginAsUser.Location = new System.Drawing.Point(196, 142);
            this.button_loginAsUser.Name = "button_loginAsUser";
            this.button_loginAsUser.Size = new System.Drawing.Size(75, 33);
            this.button_loginAsUser.TabIndex = 0;
            this.button_loginAsUser.Text = "login as user";
            this.button_loginAsUser.UseVisualStyleBackColor = true;
            this.button_loginAsUser.Click += new System.EventHandler(this.button_loginAsUser_Click);
            // 
            // Form_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(298, 189);
            this.Controls.Add(this.button_loginAsUser);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.textBox_Password);
            this.Controls.Add(this.textBox_Username);
            this.Controls.Add(this.button_Continue);
            this.Name = "Form_login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Login";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Continue;
        private System.Windows.Forms.TextBox textBox_Username;
        private System.Windows.Forms.TextBox textBox_Password;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_loginAsUser;
    }
}