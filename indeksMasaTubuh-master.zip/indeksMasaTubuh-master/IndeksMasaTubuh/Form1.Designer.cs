﻿namespace IndeksMasaTubuh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.AGaugeRange aGaugeRange37 = new System.Windows.Forms.AGaugeRange();
            System.Windows.Forms.AGaugeRange aGaugeRange38 = new System.Windows.Forms.AGaugeRange();
            System.Windows.Forms.AGaugeRange aGaugeRange39 = new System.Windows.Forms.AGaugeRange();
            System.Windows.Forms.AGaugeRange aGaugeRange40 = new System.Windows.Forms.AGaugeRange();
            System.Windows.Forms.AGaugeRange aGaugeRange41 = new System.Windows.Forms.AGaugeRange();
            System.Windows.Forms.AGaugeRange aGaugeRange42 = new System.Windows.Forms.AGaugeRange();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabIMT = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button_IMT_print = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cartesianChart_IMT_tinggi = new LiveCharts.WinForms.CartesianChart();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.aGauge_IMT_berat_badan = new System.Windows.Forms.AGauge();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.dateTimePicker_IMT = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox_IMT_tinggi = new System.Windows.Forms.TextBox();
            this.label_IMT_Tinggi = new System.Windows.Forms.Label();
            this.textBox_IMT_berat = new System.Windows.Forms.TextBox();
            this.label_IMT_Berat = new System.Windows.Forms.Label();
            this.button_GetData = new System.Windows.Forms.Button();
            this.textBox_IMT_Korps = new System.Windows.Forms.TextBox();
            this.label_beratDiubah = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_IMT_toBeratIdeal = new System.Windows.Forms.TextBox();
            this.textBox_IMT_NRP = new System.Windows.Forms.TextBox();
            this.comboBox_IMT_Pangkat = new System.Windows.Forms.ComboBox();
            this.textBox_IMT_Nama = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label_IMT_Nrp = new System.Windows.Forms.Label();
            this.label_IMT_Korp = new System.Windows.Forms.Label();
            this.label_IMT_Pangkat = new System.Windows.Forms.Label();
            this.label_IMT_nama = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label_judul = new System.Windows.Forms.Label();
            this.groupBox_IMT_Gauge = new System.Windows.Forms.GroupBox();
            this.label_IMT_value = new System.Windows.Forms.Label();
            this.textBox_IMT_value = new System.Windows.Forms.TextBox();
            this.aGauge_IMT_IMT = new System.Windows.Forms.AGauge();
            this.button_IMT_simpan = new System.Windows.Forms.Button();
            this.textBox_IMT_Status = new System.Windows.Forms.TextBox();
            this.label_IMT_Status = new System.Windows.Forms.Label();
            this.button_IMT_Hapus = new System.Windows.Forms.Button();
            this.tabData = new System.Windows.Forms.TabPage();
            this.button_DataTable_export = new System.Windows.Forms.Button();
            this.button_DataTable_Print = new System.Windows.Forms.Button();
            this.textBox_DataTable_search = new System.Windows.Forms.TextBox();
            this.dataGridView_DataTbaleIMT_Public = new System.Windows.Forms.DataGridView();
            this.tab_DataIndividual = new System.Windows.Forms.TabPage();
            this.button_DataIndividual_Print = new System.Windows.Forms.Button();
            this.textBox_DataIndividual_Pangkat = new System.Windows.Forms.TextBox();
            this.textBox_DataIndividual_Korps = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_DataIndividual_NRP = new System.Windows.Forms.TextBox();
            this.textBox_DataIndividual_Nama = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label_DataIndividual_NRP = new System.Windows.Forms.Label();
            this.label_DataIndividual_Korp = new System.Windows.Forms.Label();
            this.label_DataIndividual_Pangkat = new System.Windows.Forms.Label();
            this.label_DataIndividual_Nama = new System.Windows.Forms.Label();
            this.dataGridView_DataIndividual = new System.Windows.Forms.DataGridView();
            this.tabI_DataChart = new System.Windows.Forms.TabPage();
            this.button_DataChart_Print = new System.Windows.Forms.Button();
            this.textBox_DataChart_Pangkat = new System.Windows.Forms.TextBox();
            this.textBox_DataChart_Korps = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_DataChart_NRP = new System.Windows.Forms.TextBox();
            this.textBox_DataChart_Nama = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label_DataChart_NRP = new System.Windows.Forms.Label();
            this.label_DataChart_Korp = new System.Windows.Forms.Label();
            this.label_DataChart_Pangkat = new System.Windows.Forms.Label();
            this.label_DataChart_Nama = new System.Windows.Forms.Label();
            this.cartesianChart_DataChart = new LiveCharts.WinForms.CartesianChart();
            this.tabSolusi = new System.Windows.Forms.TabPage();
            this.button_Solusi_Print = new System.Windows.Forms.Button();
            this.textBox_Solusi_Pangkat = new System.Windows.Forms.TextBox();
            this.textBox_Solusi_Korp = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox_Solusi_NRP = new System.Windows.Forms.TextBox();
            this.textBox_Solusi_Nama = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label_Solusi_NRP = new System.Windows.Forms.Label();
            this.label_Solusi_Korp = new System.Windows.Forms.Label();
            this.label_Solusi_Pangkat = new System.Windows.Forms.Label();
            this.label_Solusi_Nama = new System.Windows.Forms.Label();
            this.dataGridView_Solusi = new System.Windows.Forms.DataGridView();
            this.comboBox_BaudRate = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.com_refresh = new System.Windows.Forms.Button();
            this.comboBox_ComPort = new System.Windows.Forms.ComboBox();
            this.button_ComOpenClose = new System.Windows.Forms.Button();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            this.printDocument_IMT = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog_IMT = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument_DataTable = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog_DataTable = new System.Windows.Forms.PrintPreviewDialog();
            this.printPreviewDialog_DataIndividual = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument_DataIndividual = new System.Drawing.Printing.PrintDocument();
            this.printDocument_DataChart = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog_DataChart = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument_solusi = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog_solusi = new System.Windows.Forms.PrintPreviewDialog();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button_login = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabIMT.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox_IMT_Gauge.SuspendLayout();
            this.tabData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DataTbaleIMT_Public)).BeginInit();
            this.tab_DataIndividual.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DataIndividual)).BeginInit();
            this.tabI_DataChart.SuspendLayout();
            this.tabSolusi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Solusi)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl1.Controls.Add(this.tabIMT);
            this.tabControl1.Controls.Add(this.tabData);
            this.tabControl1.Controls.Add(this.tab_DataIndividual);
            this.tabControl1.Controls.Add(this.tabI_DataChart);
            this.tabControl1.Controls.Add(this.tabSolusi);
            this.tabControl1.HotTrack = true;
            this.tabControl1.ItemSize = new System.Drawing.Size(150, 21);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(10, 3);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.ShowToolTips = true;
            this.tabControl1.Size = new System.Drawing.Size(1326, 663);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 0;
            // 
            // tabIMT
            // 
            this.tabIMT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabIMT.Controls.Add(this.groupBox3);
            this.tabIMT.Location = new System.Drawing.Point(4, 25);
            this.tabIMT.Name = "tabIMT";
            this.tabIMT.Padding = new System.Windows.Forms.Padding(3);
            this.tabIMT.Size = new System.Drawing.Size(1318, 634);
            this.tabIMT.TabIndex = 0;
            this.tabIMT.Text = "Ambil Data IMT";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.RoyalBlue;
            this.groupBox3.Controls.Add(this.button_IMT_print);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label_judul);
            this.groupBox3.Controls.Add(this.groupBox_IMT_Gauge);
            this.groupBox3.Controls.Add(this.button_IMT_simpan);
            this.groupBox3.Controls.Add(this.textBox_IMT_Status);
            this.groupBox3.Controls.Add(this.label_IMT_Status);
            this.groupBox3.Controls.Add(this.button_IMT_Hapus);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1312, 628);
            this.groupBox3.TabIndex = 37;
            this.groupBox3.TabStop = false;
            // 
            // button_IMT_print
            // 
            this.button_IMT_print.Location = new System.Drawing.Point(1145, 557);
            this.button_IMT_print.Name = "button_IMT_print";
            this.button_IMT_print.Size = new System.Drawing.Size(116, 32);
            this.button_IMT_print.TabIndex = 47;
            this.button_IMT_print.Text = "Print";
            this.button_IMT_print.UseVisualStyleBackColor = true;
            this.button_IMT_print.Click += new System.EventHandler(this.button_IMT_print_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.cartesianChart_IMT_tinggi);
            this.groupBox4.Location = new System.Drawing.Point(24, 181);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(104, 382);
            this.groupBox4.TabIndex = 51;
            this.groupBox4.TabStop = false;
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(16, 327);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(71, 31);
            this.label22.TabIndex = 13;
            this.label22.Text = "Tinggi";
            // 
            // cartesianChart_IMT_tinggi
            // 
            this.cartesianChart_IMT_tinggi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cartesianChart_IMT_tinggi.BackColor = System.Drawing.Color.RoyalBlue;
            this.cartesianChart_IMT_tinggi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cartesianChart_IMT_tinggi.ForeColor = System.Drawing.Color.Red;
            this.cartesianChart_IMT_tinggi.Location = new System.Drawing.Point(3, 12);
            this.cartesianChart_IMT_tinggi.Name = "cartesianChart_IMT_tinggi";
            this.cartesianChart_IMT_tinggi.Size = new System.Drawing.Size(95, 312);
            this.cartesianChart_IMT_tinggi.TabIndex = 36;
            this.cartesianChart_IMT_tinggi.Text = "cartesianChart1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.aGauge_IMT_berat_badan);
            this.groupBox2.Location = new System.Drawing.Point(548, 162);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(287, 320);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(106, 262);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(66, 24);
            this.label21.TabIndex = 12;
            this.label21.Text = "Berat\t";
            // 
            // aGauge_IMT_berat_badan
            // 
            this.aGauge_IMT_berat_badan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.aGauge_IMT_berat_badan.BaseArcColor = System.Drawing.Color.Maroon;
            this.aGauge_IMT_berat_badan.BaseArcRadius = 125;
            this.aGauge_IMT_berat_badan.BaseArcStart = 135;
            this.aGauge_IMT_berat_badan.BaseArcSweep = 270;
            this.aGauge_IMT_berat_badan.BaseArcWidth = 2;
            this.aGauge_IMT_berat_badan.Center = new System.Drawing.Point(100, 100);
            aGaugeRange37.Color = System.Drawing.Color.Lime;
            aGaugeRange37.EndValue = 40F;
            aGaugeRange37.InnerRadius = 105;
            aGaugeRange37.InRange = false;
            aGaugeRange37.Name = "GaugeRange1";
            aGaugeRange37.OuterRadius = 125;
            aGaugeRange37.StartValue = 40F;
            this.aGauge_IMT_berat_badan.GaugeRanges.Add(aGaugeRange37);
            this.aGauge_IMT_berat_badan.Location = new System.Drawing.Point(-6, 0);
            this.aGauge_IMT_berat_badan.MaxValue = 120F;
            this.aGauge_IMT_berat_badan.MinValue = 40F;
            this.aGauge_IMT_berat_badan.Name = "aGauge_IMT_berat_badan";
            this.aGauge_IMT_berat_badan.NeedleColor1 = System.Windows.Forms.AGaugeNeedleColor.Gray;
            this.aGauge_IMT_berat_badan.NeedleColor2 = System.Drawing.Color.Maroon;
            this.aGauge_IMT_berat_badan.NeedleRadius = 95;
            this.aGauge_IMT_berat_badan.NeedleType = System.Windows.Forms.NeedleType.Advance;
            this.aGauge_IMT_berat_badan.NeedleWidth = 3;
            this.aGauge_IMT_berat_badan.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge_IMT_berat_badan.ScaleLinesInterInnerRadius = 110;
            this.aGauge_IMT_berat_badan.ScaleLinesInterOuterRadius = 125;
            this.aGauge_IMT_berat_badan.ScaleLinesInterWidth = 2;
            this.aGauge_IMT_berat_badan.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge_IMT_berat_badan.ScaleLinesMajorInnerRadius = 105;
            this.aGauge_IMT_berat_badan.ScaleLinesMajorOuterRadius = 125;
            this.aGauge_IMT_berat_badan.ScaleLinesMajorStepValue = 10F;
            this.aGauge_IMT_berat_badan.ScaleLinesMajorWidth = 3;
            this.aGauge_IMT_berat_badan.ScaleLinesMinorColor = System.Drawing.Color.Gray;
            this.aGauge_IMT_berat_badan.ScaleLinesMinorInnerRadius = 110;
            this.aGauge_IMT_berat_badan.ScaleLinesMinorOuterRadius = 125;
            this.aGauge_IMT_berat_badan.ScaleLinesMinorTicks = 9;
            this.aGauge_IMT_berat_badan.ScaleLinesMinorWidth = 1;
            this.aGauge_IMT_berat_badan.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge_IMT_berat_badan.ScaleNumbersFormat = null;
            this.aGauge_IMT_berat_badan.ScaleNumbersRadius = 95;
            this.aGauge_IMT_berat_badan.ScaleNumbersRotation = 0;
            this.aGauge_IMT_berat_badan.ScaleNumbersStartScaleLine = 1;
            this.aGauge_IMT_berat_badan.ScaleNumbersStepScaleLines = 20;
            this.aGauge_IMT_berat_badan.Size = new System.Drawing.Size(293, 299);
            this.aGauge_IMT_berat_badan.TabIndex = 34;
            this.aGauge_IMT_berat_badan.Text = "aGauge2";
            this.aGauge_IMT_berat_badan.Value = 40F;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::IndeksMasaTubuh.Properties.Resources.logo_transparent;
            this.pictureBox2.Location = new System.Drawing.Point(1112, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(117, 112);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 50;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::IndeksMasaTubuh.Properties.Resources.Logo_TNI_AL;
            this.pictureBox1.Location = new System.Drawing.Point(59, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.dateTimePicker_IMT);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.textBox_IMT_tinggi);
            this.groupBox1.Controls.Add(this.label_IMT_Tinggi);
            this.groupBox1.Controls.Add(this.textBox_IMT_berat);
            this.groupBox1.Controls.Add(this.label_IMT_Berat);
            this.groupBox1.Controls.Add(this.button_GetData);
            this.groupBox1.Controls.Add(this.textBox_IMT_Korps);
            this.groupBox1.Controls.Add(this.label_beratDiubah);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBox_IMT_toBeratIdeal);
            this.groupBox1.Controls.Add(this.textBox_IMT_NRP);
            this.groupBox1.Controls.Add(this.comboBox_IMT_Pangkat);
            this.groupBox1.Controls.Add(this.textBox_IMT_Nama);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label_IMT_Nrp);
            this.groupBox1.Controls.Add(this.label_IMT_Korp);
            this.groupBox1.Controls.Add(this.label_IMT_Pangkat);
            this.groupBox1.Controls.Add(this.label_IMT_nama);
            this.groupBox1.Location = new System.Drawing.Point(878, 188);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(383, 363);
            this.groupBox1.TabIndex = 47;
            this.groupBox1.TabStop = false;
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(131, 202);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(15, 24);
            this.label24.TabIndex = 54;
            this.label24.Text = ":";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(41, 205);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(93, 24);
            this.label23.TabIndex = 53;
            this.label23.Text = "Tgl Ambil";
            // 
            // dateTimePicker_IMT
            // 
            this.dateTimePicker_IMT.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_IMT.Location = new System.Drawing.Point(150, 205);
            this.dateTimePicker_IMT.Name = "dateTimePicker_IMT";
            this.dateTimePicker_IMT.Size = new System.Drawing.Size(134, 20);
            this.dateTimePicker_IMT.TabIndex = 52;
            this.dateTimePicker_IMT.ValueChanged += new System.EventHandler(this.dateTimePicker_IMT_ValueChanged);
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(131, 173);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 24);
            this.label20.TabIndex = 46;
            this.label20.Text = ":";
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(132, 135);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 24);
            this.label19.TabIndex = 45;
            this.label19.Text = ":";
            // 
            // textBox_IMT_tinggi
            // 
            this.textBox_IMT_tinggi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_IMT_tinggi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IMT_tinggi.Location = new System.Drawing.Point(150, 135);
            this.textBox_IMT_tinggi.Name = "textBox_IMT_tinggi";
            this.textBox_IMT_tinggi.Size = new System.Drawing.Size(134, 26);
            this.textBox_IMT_tinggi.TabIndex = 16;
            this.textBox_IMT_tinggi.Enter += new System.EventHandler(this.textBox_IMT_tinggi_Enter);
            // 
            // label_IMT_Tinggi
            // 
            this.label_IMT_Tinggi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_IMT_Tinggi.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IMT_Tinggi.Location = new System.Drawing.Point(44, 133);
            this.label_IMT_Tinggi.Name = "label_IMT_Tinggi";
            this.label_IMT_Tinggi.Size = new System.Drawing.Size(64, 24);
            this.label_IMT_Tinggi.TabIndex = 13;
            this.label_IMT_Tinggi.Text = "Tinggi";
            // 
            // textBox_IMT_berat
            // 
            this.textBox_IMT_berat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_IMT_berat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IMT_berat.Location = new System.Drawing.Point(149, 173);
            this.textBox_IMT_berat.Name = "textBox_IMT_berat";
            this.textBox_IMT_berat.Size = new System.Drawing.Size(135, 26);
            this.textBox_IMT_berat.TabIndex = 17;
            this.textBox_IMT_berat.TextChanged += new System.EventHandler(this.textBox_IMT_berat_TextChanged);
            this.textBox_IMT_berat.Enter += new System.EventHandler(this.textBox_IMT_berat_Enter);
            this.textBox_IMT_berat.Leave += new System.EventHandler(this.textBox_IMT_berat_Leave);
            // 
            // label_IMT_Berat
            // 
            this.label_IMT_Berat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_IMT_Berat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IMT_Berat.Location = new System.Drawing.Point(44, 173);
            this.label_IMT_Berat.Name = "label_IMT_Berat";
            this.label_IMT_Berat.Size = new System.Drawing.Size(55, 24);
            this.label_IMT_Berat.TabIndex = 12;
            this.label_IMT_Berat.Text = "Berat\t";
            // 
            // button_GetData
            // 
            this.button_GetData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_GetData.Location = new System.Drawing.Point(150, 231);
            this.button_GetData.Name = "button_GetData";
            this.button_GetData.Size = new System.Drawing.Size(134, 36);
            this.button_GetData.TabIndex = 5;
            this.button_GetData.Text = "Ambil Data Tinggi dan Berat";
            this.button_GetData.UseVisualStyleBackColor = true;
            this.button_GetData.Click += new System.EventHandler(this.button_GetData_Click);
            // 
            // textBox_IMT_Korps
            // 
            this.textBox_IMT_Korps.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_IMT_Korps.Location = new System.Drawing.Point(150, 109);
            this.textBox_IMT_Korps.Name = "textBox_IMT_Korps";
            this.textBox_IMT_Korps.Size = new System.Drawing.Size(219, 20);
            this.textBox_IMT_Korps.TabIndex = 4;
            // 
            // label_beratDiubah
            // 
            this.label_beratDiubah.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_beratDiubah.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_beratDiubah.Location = new System.Drawing.Point(74, 286);
            this.label_beratDiubah.Name = "label_beratDiubah";
            this.label_beratDiubah.Size = new System.Drawing.Size(272, 24);
            this.label_beratDiubah.TabIndex = 41;
            this.label_beratDiubah.Text = "Berat Badan Yang Harus Diubah";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(132, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 24);
            this.label9.TabIndex = 28;
            this.label9.Text = ":";
            // 
            // textBox_IMT_toBeratIdeal
            // 
            this.textBox_IMT_toBeratIdeal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_IMT_toBeratIdeal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IMT_toBeratIdeal.Location = new System.Drawing.Point(144, 313);
            this.textBox_IMT_toBeratIdeal.Name = "textBox_IMT_toBeratIdeal";
            this.textBox_IMT_toBeratIdeal.ReadOnly = true;
            this.textBox_IMT_toBeratIdeal.Size = new System.Drawing.Size(135, 29);
            this.textBox_IMT_toBeratIdeal.TabIndex = 42;
            this.textBox_IMT_toBeratIdeal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_IMT_NRP
            // 
            this.textBox_IMT_NRP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_IMT_NRP.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.textBox_IMT_NRP.Location = new System.Drawing.Point(150, 26);
            this.textBox_IMT_NRP.Name = "textBox_IMT_NRP";
            this.textBox_IMT_NRP.Size = new System.Drawing.Size(219, 20);
            this.textBox_IMT_NRP.TabIndex = 1;
            this.textBox_IMT_NRP.Leave += new System.EventHandler(this.textBox_IMT_NRP_LeaveEvent);
            // 
            // comboBox_IMT_Pangkat
            // 
            this.comboBox_IMT_Pangkat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox_IMT_Pangkat.FormattingEnabled = true;
            this.comboBox_IMT_Pangkat.Items.AddRange(new object[] {
            "Kld",
            "Kls",
            "Klk",
            "Kopda",
            "Koptu",
            "Kopka",
            "Serda",
            "Sertu",
            "Serka",
            "Serma",
            "Pelda",
            "Peltu",
            "Letda",
            "Lettu",
            "Kapten",
            "Mayor",
            "Letkol",
            "Kolonel"});
            this.comboBox_IMT_Pangkat.Location = new System.Drawing.Point(150, 80);
            this.comboBox_IMT_Pangkat.Name = "comboBox_IMT_Pangkat";
            this.comboBox_IMT_Pangkat.Size = new System.Drawing.Size(219, 21);
            this.comboBox_IMT_Pangkat.TabIndex = 3;
            // 
            // textBox_IMT_Nama
            // 
            this.textBox_IMT_Nama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_IMT_Nama.Location = new System.Drawing.Point(150, 54);
            this.textBox_IMT_Nama.Name = "textBox_IMT_Nama";
            this.textBox_IMT_Nama.Size = new System.Drawing.Size(219, 20);
            this.textBox_IMT_Nama.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(132, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = ":";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(132, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = ":";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(132, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = ":";
            // 
            // label_IMT_Nrp
            // 
            this.label_IMT_Nrp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_IMT_Nrp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IMT_Nrp.Location = new System.Drawing.Point(44, 24);
            this.label_IMT_Nrp.Name = "label_IMT_Nrp";
            this.label_IMT_Nrp.Size = new System.Drawing.Size(100, 24);
            this.label_IMT_Nrp.TabIndex = 3;
            this.label_IMT_Nrp.Text = "NRP";
            // 
            // label_IMT_Korp
            // 
            this.label_IMT_Korp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_IMT_Korp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IMT_Korp.Location = new System.Drawing.Point(44, 102);
            this.label_IMT_Korp.Name = "label_IMT_Korp";
            this.label_IMT_Korp.Size = new System.Drawing.Size(100, 24);
            this.label_IMT_Korp.TabIndex = 2;
            this.label_IMT_Korp.Text = "Korp";
            // 
            // label_IMT_Pangkat
            // 
            this.label_IMT_Pangkat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_IMT_Pangkat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IMT_Pangkat.Location = new System.Drawing.Point(44, 75);
            this.label_IMT_Pangkat.Name = "label_IMT_Pangkat";
            this.label_IMT_Pangkat.Size = new System.Drawing.Size(100, 24);
            this.label_IMT_Pangkat.TabIndex = 1;
            this.label_IMT_Pangkat.Text = "Pangkat\t";
            // 
            // label_IMT_nama
            // 
            this.label_IMT_nama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_IMT_nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IMT_nama.Location = new System.Drawing.Point(44, 48);
            this.label_IMT_nama.Name = "label_IMT_nama";
            this.label_IMT_nama.Size = new System.Drawing.Size(100, 24);
            this.label_IMT_nama.TabIndex = 0;
            this.label_IMT_nama.Text = "Nama\t";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Orange;
            this.label18.Location = new System.Drawing.Point(249, 91);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(802, 37);
            this.label18.TabIndex = 44;
            this.label18.Text = "SEKOLAH TINGGI TEKNOLOGI ANGKATAN LAUT";
            // 
            // label_judul
            // 
            this.label_judul.AutoSize = true;
            this.label_judul.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_judul.ForeColor = System.Drawing.Color.Orange;
            this.label_judul.Location = new System.Drawing.Point(275, 36);
            this.label_judul.Name = "label_judul";
            this.label_judul.Size = new System.Drawing.Size(751, 37);
            this.label_judul.TabIndex = 43;
            this.label_judul.Text = "APLIKASI ALAT UKUR INDEKS MASSA TUBUH";
            // 
            // groupBox_IMT_Gauge
            // 
            this.groupBox_IMT_Gauge.Controls.Add(this.label_IMT_value);
            this.groupBox_IMT_Gauge.Controls.Add(this.textBox_IMT_value);
            this.groupBox_IMT_Gauge.Controls.Add(this.aGauge_IMT_IMT);
            this.groupBox_IMT_Gauge.Location = new System.Drawing.Point(191, 144);
            this.groupBox_IMT_Gauge.Name = "groupBox_IMT_Gauge";
            this.groupBox_IMT_Gauge.Size = new System.Drawing.Size(311, 338);
            this.groupBox_IMT_Gauge.TabIndex = 37;
            this.groupBox_IMT_Gauge.TabStop = false;
            // 
            // label_IMT_value
            // 
            this.label_IMT_value.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_IMT_value.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IMT_value.Location = new System.Drawing.Point(147, 310);
            this.label_IMT_value.Name = "label_IMT_value";
            this.label_IMT_value.Size = new System.Drawing.Size(42, 24);
            this.label_IMT_value.TabIndex = 36;
            this.label_IMT_value.Text = "IMT\t";
            // 
            // textBox_IMT_value
            // 
            this.textBox_IMT_value.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_IMT_value.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IMT_value.Location = new System.Drawing.Point(130, 277);
            this.textBox_IMT_value.Name = "textBox_IMT_value";
            this.textBox_IMT_value.ReadOnly = true;
            this.textBox_IMT_value.Size = new System.Drawing.Size(69, 26);
            this.textBox_IMT_value.TabIndex = 36;
            // 
            // aGauge_IMT_IMT
            // 
            this.aGauge_IMT_IMT.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.aGauge_IMT_IMT.BaseArcColor = System.Drawing.Color.Blue;
            this.aGauge_IMT_IMT.BaseArcRadius = 125;
            this.aGauge_IMT_IMT.BaseArcStart = 135;
            this.aGauge_IMT_IMT.BaseArcSweep = 270;
            this.aGauge_IMT_IMT.BaseArcWidth = 2;
            this.aGauge_IMT_IMT.Center = new System.Drawing.Point(112, 112);
            aGaugeRange38.Color = System.Drawing.Color.Empty;
            aGaugeRange38.EndValue = 0F;
            aGaugeRange38.InnerRadius = 1;
            aGaugeRange38.InRange = false;
            aGaugeRange38.Name = "GaugeRange1";
            aGaugeRange38.OuterRadius = 2;
            aGaugeRange38.StartValue = 0F;
            aGaugeRange39.Color = System.Drawing.Color.Yellow;
            aGaugeRange39.EndValue = 18.5F;
            aGaugeRange39.InnerRadius = 110;
            aGaugeRange39.InRange = true;
            aGaugeRange39.Name = "GaugeRange1";
            aGaugeRange39.OuterRadius = 125;
            aGaugeRange39.StartValue = 16F;
            aGaugeRange40.Color = System.Drawing.Color.Lime;
            aGaugeRange40.EndValue = 25F;
            aGaugeRange40.InnerRadius = 110;
            aGaugeRange40.InRange = false;
            aGaugeRange40.Name = "GaugeRange2";
            aGaugeRange40.OuterRadius = 125;
            aGaugeRange40.StartValue = 18.5F;
            aGaugeRange41.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            aGaugeRange41.EndValue = 30F;
            aGaugeRange41.InnerRadius = 110;
            aGaugeRange41.InRange = false;
            aGaugeRange41.Name = "GaugeRange3";
            aGaugeRange41.OuterRadius = 125;
            aGaugeRange41.StartValue = 25F;
            aGaugeRange42.Color = System.Drawing.Color.Red;
            aGaugeRange42.EndValue = 32F;
            aGaugeRange42.InnerRadius = 110;
            aGaugeRange42.InRange = false;
            aGaugeRange42.Name = "GaugeRange4";
            aGaugeRange42.OuterRadius = 125;
            aGaugeRange42.StartValue = 30F;
            this.aGauge_IMT_IMT.GaugeRanges.Add(aGaugeRange38);
            this.aGauge_IMT_IMT.GaugeRanges.Add(aGaugeRange39);
            this.aGauge_IMT_IMT.GaugeRanges.Add(aGaugeRange40);
            this.aGauge_IMT_IMT.GaugeRanges.Add(aGaugeRange41);
            this.aGauge_IMT_IMT.GaugeRanges.Add(aGaugeRange42);
            this.aGauge_IMT_IMT.Location = new System.Drawing.Point(-25, 0);
            this.aGauge_IMT_IMT.MaxValue = 32F;
            this.aGauge_IMT_IMT.MinValue = 16F;
            this.aGauge_IMT_IMT.Name = "aGauge_IMT_IMT";
            this.aGauge_IMT_IMT.NeedleColor1 = System.Windows.Forms.AGaugeNeedleColor.Gray;
            this.aGauge_IMT_IMT.NeedleColor2 = System.Drawing.Color.RoyalBlue;
            this.aGauge_IMT_IMT.NeedleRadius = 115;
            this.aGauge_IMT_IMT.NeedleType = System.Windows.Forms.NeedleType.Advance;
            this.aGauge_IMT_IMT.NeedleWidth = 4;
            this.aGauge_IMT_IMT.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge_IMT_IMT.ScaleLinesInterInnerRadius = 100;
            this.aGauge_IMT_IMT.ScaleLinesInterOuterRadius = 125;
            this.aGauge_IMT_IMT.ScaleLinesInterWidth = 1;
            this.aGauge_IMT_IMT.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge_IMT_IMT.ScaleLinesMajorInnerRadius = 100;
            this.aGauge_IMT_IMT.ScaleLinesMajorOuterRadius = 125;
            this.aGauge_IMT_IMT.ScaleLinesMajorStepValue = 2F;
            this.aGauge_IMT_IMT.ScaleLinesMajorWidth = 2;
            this.aGauge_IMT_IMT.ScaleLinesMinorColor = System.Drawing.Color.Black;
            this.aGauge_IMT_IMT.ScaleLinesMinorInnerRadius = 110;
            this.aGauge_IMT_IMT.ScaleLinesMinorOuterRadius = 125;
            this.aGauge_IMT_IMT.ScaleLinesMinorTicks = 3;
            this.aGauge_IMT_IMT.ScaleLinesMinorWidth = 1;
            this.aGauge_IMT_IMT.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge_IMT_IMT.ScaleNumbersFormat = null;
            this.aGauge_IMT_IMT.ScaleNumbersRadius = 90;
            this.aGauge_IMT_IMT.ScaleNumbersRotation = 0;
            this.aGauge_IMT_IMT.ScaleNumbersStartScaleLine = 1;
            this.aGauge_IMT_IMT.ScaleNumbersStepScaleLines = 1;
            this.aGauge_IMT_IMT.Size = new System.Drawing.Size(351, 315);
            this.aGauge_IMT_IMT.TabIndex = 35;
            this.aGauge_IMT_IMT.Text = "aGauge3";
            this.aGauge_IMT_IMT.Value = 16F;
            // 
            // button_IMT_simpan
            // 
            this.button_IMT_simpan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_IMT_simpan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_IMT_simpan.Location = new System.Drawing.Point(878, 557);
            this.button_IMT_simpan.Name = "button_IMT_simpan";
            this.button_IMT_simpan.Size = new System.Drawing.Size(134, 32);
            this.button_IMT_simpan.TabIndex = 6;
            this.button_IMT_simpan.Text = "Simpan";
            this.button_IMT_simpan.UseVisualStyleBackColor = true;
            this.button_IMT_simpan.Click += new System.EventHandler(this.button_IMT_simpan_Click);
            // 
            // textBox_IMT_Status
            // 
            this.textBox_IMT_Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_IMT_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IMT_Status.Location = new System.Drawing.Point(399, 560);
            this.textBox_IMT_Status.Name = "textBox_IMT_Status";
            this.textBox_IMT_Status.ReadOnly = true;
            this.textBox_IMT_Status.Size = new System.Drawing.Size(280, 29);
            this.textBox_IMT_Status.TabIndex = 32;
            this.textBox_IMT_Status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label_IMT_Status
            // 
            this.label_IMT_Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_IMT_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IMT_Status.ForeColor = System.Drawing.Color.Orange;
            this.label_IMT_Status.Location = new System.Drawing.Point(395, 515);
            this.label_IMT_Status.Name = "label_IMT_Status";
            this.label_IMT_Status.Size = new System.Drawing.Size(284, 24);
            this.label_IMT_Status.TabIndex = 30;
            this.label_IMT_Status.Text = "INDEKS MASSA TUBUH\t";
            // 
            // button_IMT_Hapus
            // 
            this.button_IMT_Hapus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_IMT_Hapus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_IMT_Hapus.Location = new System.Drawing.Point(1020, 557);
            this.button_IMT_Hapus.Name = "button_IMT_Hapus";
            this.button_IMT_Hapus.Size = new System.Drawing.Size(117, 32);
            this.button_IMT_Hapus.TabIndex = 7;
            this.button_IMT_Hapus.Text = "Hapus";
            this.button_IMT_Hapus.UseVisualStyleBackColor = true;
            this.button_IMT_Hapus.Click += new System.EventHandler(this.button_IMT_Hapus_Click);
            // 
            // tabData
            // 
            this.tabData.Controls.Add(this.button_DataTable_export);
            this.tabData.Controls.Add(this.button_DataTable_Print);
            this.tabData.Controls.Add(this.textBox_DataTable_search);
            this.tabData.Controls.Add(this.dataGridView_DataTbaleIMT_Public);
            this.tabData.Location = new System.Drawing.Point(4, 25);
            this.tabData.Name = "tabData";
            this.tabData.Padding = new System.Windows.Forms.Padding(3);
            this.tabData.Size = new System.Drawing.Size(1318, 634);
            this.tabData.TabIndex = 1;
            this.tabData.Text = "Data Table";
            this.tabData.UseVisualStyleBackColor = true;
            this.tabData.Enter += new System.EventHandler(this.tabData_enterEvent);
            // 
            // button_DataTable_export
            // 
            this.button_DataTable_export.Location = new System.Drawing.Point(6, 18);
            this.button_DataTable_export.Name = "button_DataTable_export";
            this.button_DataTable_export.Size = new System.Drawing.Size(98, 23);
            this.button_DataTable_export.TabIndex = 3;
            this.button_DataTable_export.Text = "Refresh";
            this.button_DataTable_export.UseVisualStyleBackColor = true;
            this.button_DataTable_export.Click += new System.EventHandler(this.buttonDataTableExport_Click);
            // 
            // button_DataTable_Print
            // 
            this.button_DataTable_Print.Location = new System.Drawing.Point(124, 19);
            this.button_DataTable_Print.Name = "button_DataTable_Print";
            this.button_DataTable_Print.Size = new System.Drawing.Size(75, 23);
            this.button_DataTable_Print.TabIndex = 2;
            this.button_DataTable_Print.Text = "Print";
            this.button_DataTable_Print.UseVisualStyleBackColor = true;
            this.button_DataTable_Print.Click += new System.EventHandler(this.button_DataTable_Print_Click);
            // 
            // textBox_DataTable_search
            // 
            this.textBox_DataTable_search.Location = new System.Drawing.Point(1103, 21);
            this.textBox_DataTable_search.Name = "textBox_DataTable_search";
            this.textBox_DataTable_search.Size = new System.Drawing.Size(189, 20);
            this.textBox_DataTable_search.TabIndex = 1;
            this.textBox_DataTable_search.TextChanged += new System.EventHandler(this.textBox_DataTable_Search_TextChanged);
            // 
            // dataGridView_DataTbaleIMT_Public
            // 
            this.dataGridView_DataTbaleIMT_Public.AllowUserToAddRows = false;
            this.dataGridView_DataTbaleIMT_Public.AllowUserToDeleteRows = false;
            this.dataGridView_DataTbaleIMT_Public.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_DataTbaleIMT_Public.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_DataTbaleIMT_Public.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_DataTbaleIMT_Public.Location = new System.Drawing.Point(6, 47);
            this.dataGridView_DataTbaleIMT_Public.Name = "dataGridView_DataTbaleIMT_Public";
            this.dataGridView_DataTbaleIMT_Public.ReadOnly = true;
            this.dataGridView_DataTbaleIMT_Public.Size = new System.Drawing.Size(1286, 581);
            this.dataGridView_DataTbaleIMT_Public.TabIndex = 0;
            this.dataGridView_DataTbaleIMT_Public.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridview_DataTableIMT_Public_DeleteButtonClick);
            this.dataGridView_DataTbaleIMT_Public.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_DataTbaleIMT_Public_CellMouseDoubleClick);
            // 
            // tab_DataIndividual
            // 
            this.tab_DataIndividual.Controls.Add(this.button_DataIndividual_Print);
            this.tab_DataIndividual.Controls.Add(this.textBox_DataIndividual_Pangkat);
            this.tab_DataIndividual.Controls.Add(this.textBox_DataIndividual_Korps);
            this.tab_DataIndividual.Controls.Add(this.label10);
            this.tab_DataIndividual.Controls.Add(this.textBox_DataIndividual_NRP);
            this.tab_DataIndividual.Controls.Add(this.textBox_DataIndividual_Nama);
            this.tab_DataIndividual.Controls.Add(this.label11);
            this.tab_DataIndividual.Controls.Add(this.label12);
            this.tab_DataIndividual.Controls.Add(this.label13);
            this.tab_DataIndividual.Controls.Add(this.label_DataIndividual_NRP);
            this.tab_DataIndividual.Controls.Add(this.label_DataIndividual_Korp);
            this.tab_DataIndividual.Controls.Add(this.label_DataIndividual_Pangkat);
            this.tab_DataIndividual.Controls.Add(this.label_DataIndividual_Nama);
            this.tab_DataIndividual.Controls.Add(this.dataGridView_DataIndividual);
            this.tab_DataIndividual.Location = new System.Drawing.Point(4, 25);
            this.tab_DataIndividual.Name = "tab_DataIndividual";
            this.tab_DataIndividual.Padding = new System.Windows.Forms.Padding(3);
            this.tab_DataIndividual.Size = new System.Drawing.Size(1318, 634);
            this.tab_DataIndividual.TabIndex = 2;
            this.tab_DataIndividual.Text = "Data Individual";
            this.tab_DataIndividual.UseVisualStyleBackColor = true;
            // 
            // button_DataIndividual_Print
            // 
            this.button_DataIndividual_Print.Location = new System.Drawing.Point(125, 130);
            this.button_DataIndividual_Print.Name = "button_DataIndividual_Print";
            this.button_DataIndividual_Print.Size = new System.Drawing.Size(100, 23);
            this.button_DataIndividual_Print.TabIndex = 54;
            this.button_DataIndividual_Print.Text = "Print";
            this.button_DataIndividual_Print.UseVisualStyleBackColor = true;
            this.button_DataIndividual_Print.Click += new System.EventHandler(this.button_DataIndividual_Print_Click);
            // 
            // textBox_DataIndividual_Pangkat
            // 
            this.textBox_DataIndividual_Pangkat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_DataIndividual_Pangkat.Location = new System.Drawing.Point(125, 78);
            this.textBox_DataIndividual_Pangkat.Name = "textBox_DataIndividual_Pangkat";
            this.textBox_DataIndividual_Pangkat.ReadOnly = true;
            this.textBox_DataIndividual_Pangkat.Size = new System.Drawing.Size(100, 20);
            this.textBox_DataIndividual_Pangkat.TabIndex = 53;
            // 
            // textBox_DataIndividual_Korps
            // 
            this.textBox_DataIndividual_Korps.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_DataIndividual_Korps.Location = new System.Drawing.Point(125, 104);
            this.textBox_DataIndividual_Korps.Name = "textBox_DataIndividual_Korps";
            this.textBox_DataIndividual_Korps.ReadOnly = true;
            this.textBox_DataIndividual_Korps.Size = new System.Drawing.Size(100, 20);
            this.textBox_DataIndividual_Korps.TabIndex = 52;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(104, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 24);
            this.label10.TabIndex = 51;
            this.label10.Text = ":";
            // 
            // textBox_DataIndividual_NRP
            // 
            this.textBox_DataIndividual_NRP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_DataIndividual_NRP.Location = new System.Drawing.Point(125, 21);
            this.textBox_DataIndividual_NRP.Name = "textBox_DataIndividual_NRP";
            this.textBox_DataIndividual_NRP.Size = new System.Drawing.Size(100, 20);
            this.textBox_DataIndividual_NRP.TabIndex = 50;
            this.textBox_DataIndividual_NRP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_DataIndividual_NRP_KeyDown);
            this.textBox_DataIndividual_NRP.Leave += new System.EventHandler(this.textBox_DataIndividual_NRP_Leave);
            // 
            // textBox_DataIndividual_Nama
            // 
            this.textBox_DataIndividual_Nama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_DataIndividual_Nama.Location = new System.Drawing.Point(125, 49);
            this.textBox_DataIndividual_Nama.Name = "textBox_DataIndividual_Nama";
            this.textBox_DataIndividual_Nama.Size = new System.Drawing.Size(100, 20);
            this.textBox_DataIndividual_Nama.TabIndex = 48;
            this.textBox_DataIndividual_Nama.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_DataIndividual_Nama_KeyDown);
            this.textBox_DataIndividual_Nama.Leave += new System.EventHandler(this.textBox_DataIndividual_Nama_Leave);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(104, 99);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 24);
            this.label11.TabIndex = 47;
            this.label11.Text = ":";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(104, 72);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 24);
            this.label12.TabIndex = 46;
            this.label12.Text = ":";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(104, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 24);
            this.label13.TabIndex = 45;
            this.label13.Text = ":";
            // 
            // label_DataIndividual_NRP
            // 
            this.label_DataIndividual_NRP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DataIndividual_NRP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DataIndividual_NRP.Location = new System.Drawing.Point(16, 21);
            this.label_DataIndividual_NRP.Name = "label_DataIndividual_NRP";
            this.label_DataIndividual_NRP.Size = new System.Drawing.Size(100, 24);
            this.label_DataIndividual_NRP.TabIndex = 44;
            this.label_DataIndividual_NRP.Text = "NRP";
            // 
            // label_DataIndividual_Korp
            // 
            this.label_DataIndividual_Korp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DataIndividual_Korp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DataIndividual_Korp.Location = new System.Drawing.Point(16, 99);
            this.label_DataIndividual_Korp.Name = "label_DataIndividual_Korp";
            this.label_DataIndividual_Korp.Size = new System.Drawing.Size(100, 24);
            this.label_DataIndividual_Korp.TabIndex = 43;
            this.label_DataIndividual_Korp.Text = "Korp";
            // 
            // label_DataIndividual_Pangkat
            // 
            this.label_DataIndividual_Pangkat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DataIndividual_Pangkat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DataIndividual_Pangkat.Location = new System.Drawing.Point(16, 72);
            this.label_DataIndividual_Pangkat.Name = "label_DataIndividual_Pangkat";
            this.label_DataIndividual_Pangkat.Size = new System.Drawing.Size(100, 24);
            this.label_DataIndividual_Pangkat.TabIndex = 42;
            this.label_DataIndividual_Pangkat.Text = "Pangkat\t";
            // 
            // label_DataIndividual_Nama
            // 
            this.label_DataIndividual_Nama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DataIndividual_Nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DataIndividual_Nama.Location = new System.Drawing.Point(16, 45);
            this.label_DataIndividual_Nama.Name = "label_DataIndividual_Nama";
            this.label_DataIndividual_Nama.Size = new System.Drawing.Size(100, 24);
            this.label_DataIndividual_Nama.TabIndex = 41;
            this.label_DataIndividual_Nama.Text = "Nama\t";
            // 
            // dataGridView_DataIndividual
            // 
            this.dataGridView_DataIndividual.AllowUserToAddRows = false;
            this.dataGridView_DataIndividual.AllowUserToDeleteRows = false;
            this.dataGridView_DataIndividual.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_DataIndividual.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_DataIndividual.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_DataIndividual.Location = new System.Drawing.Point(6, 157);
            this.dataGridView_DataIndividual.Name = "dataGridView_DataIndividual";
            this.dataGridView_DataIndividual.ReadOnly = true;
            this.dataGridView_DataIndividual.Size = new System.Drawing.Size(1286, 451);
            this.dataGridView_DataIndividual.TabIndex = 2;
            this.dataGridView_DataIndividual.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridview_DataIndividual_DeleteButtonClick);
            // 
            // tabI_DataChart
            // 
            this.tabI_DataChart.Controls.Add(this.button_DataChart_Print);
            this.tabI_DataChart.Controls.Add(this.textBox_DataChart_Pangkat);
            this.tabI_DataChart.Controls.Add(this.textBox_DataChart_Korps);
            this.tabI_DataChart.Controls.Add(this.label4);
            this.tabI_DataChart.Controls.Add(this.textBox_DataChart_NRP);
            this.tabI_DataChart.Controls.Add(this.textBox_DataChart_Nama);
            this.tabI_DataChart.Controls.Add(this.label5);
            this.tabI_DataChart.Controls.Add(this.label6);
            this.tabI_DataChart.Controls.Add(this.label7);
            this.tabI_DataChart.Controls.Add(this.label_DataChart_NRP);
            this.tabI_DataChart.Controls.Add(this.label_DataChart_Korp);
            this.tabI_DataChart.Controls.Add(this.label_DataChart_Pangkat);
            this.tabI_DataChart.Controls.Add(this.label_DataChart_Nama);
            this.tabI_DataChart.Controls.Add(this.cartesianChart_DataChart);
            this.tabI_DataChart.Location = new System.Drawing.Point(4, 25);
            this.tabI_DataChart.Name = "tabI_DataChart";
            this.tabI_DataChart.Padding = new System.Windows.Forms.Padding(3);
            this.tabI_DataChart.Size = new System.Drawing.Size(1318, 634);
            this.tabI_DataChart.TabIndex = 3;
            this.tabI_DataChart.Text = "Data Chart";
            this.tabI_DataChart.UseVisualStyleBackColor = true;
            // 
            // button_DataChart_Print
            // 
            this.button_DataChart_Print.Location = new System.Drawing.Point(123, 128);
            this.button_DataChart_Print.Name = "button_DataChart_Print";
            this.button_DataChart_Print.Size = new System.Drawing.Size(100, 23);
            this.button_DataChart_Print.TabIndex = 69;
            this.button_DataChart_Print.Text = "Print";
            this.button_DataChart_Print.UseVisualStyleBackColor = true;
            this.button_DataChart_Print.Click += new System.EventHandler(this.button_DataChart_Print_Click);
            // 
            // textBox_DataChart_Pangkat
            // 
            this.textBox_DataChart_Pangkat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_DataChart_Pangkat.Location = new System.Drawing.Point(123, 74);
            this.textBox_DataChart_Pangkat.Name = "textBox_DataChart_Pangkat";
            this.textBox_DataChart_Pangkat.ReadOnly = true;
            this.textBox_DataChart_Pangkat.Size = new System.Drawing.Size(100, 20);
            this.textBox_DataChart_Pangkat.TabIndex = 68;
            // 
            // textBox_DataChart_Korps
            // 
            this.textBox_DataChart_Korps.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_DataChart_Korps.Location = new System.Drawing.Point(123, 102);
            this.textBox_DataChart_Korps.Name = "textBox_DataChart_Korps";
            this.textBox_DataChart_Korps.ReadOnly = true;
            this.textBox_DataChart_Korps.Size = new System.Drawing.Size(100, 20);
            this.textBox_DataChart_Korps.TabIndex = 67;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(102, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 24);
            this.label4.TabIndex = 66;
            this.label4.Text = ":";
            // 
            // textBox_DataChart_NRP
            // 
            this.textBox_DataChart_NRP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_DataChart_NRP.Location = new System.Drawing.Point(123, 18);
            this.textBox_DataChart_NRP.Name = "textBox_DataChart_NRP";
            this.textBox_DataChart_NRP.Size = new System.Drawing.Size(100, 20);
            this.textBox_DataChart_NRP.TabIndex = 65;
            // 
            // textBox_DataChart_Nama
            // 
            this.textBox_DataChart_Nama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_DataChart_Nama.Location = new System.Drawing.Point(123, 46);
            this.textBox_DataChart_Nama.Name = "textBox_DataChart_Nama";
            this.textBox_DataChart_Nama.Size = new System.Drawing.Size(100, 20);
            this.textBox_DataChart_Nama.TabIndex = 64;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(102, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 24);
            this.label5.TabIndex = 63;
            this.label5.Text = ":";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(102, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 24);
            this.label6.TabIndex = 62;
            this.label6.Text = ":";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(102, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 24);
            this.label7.TabIndex = 61;
            this.label7.Text = ":";
            // 
            // label_DataChart_NRP
            // 
            this.label_DataChart_NRP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DataChart_NRP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DataChart_NRP.Location = new System.Drawing.Point(14, 18);
            this.label_DataChart_NRP.Name = "label_DataChart_NRP";
            this.label_DataChart_NRP.Size = new System.Drawing.Size(100, 24);
            this.label_DataChart_NRP.TabIndex = 60;
            this.label_DataChart_NRP.Text = "NRP";
            // 
            // label_DataChart_Korp
            // 
            this.label_DataChart_Korp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DataChart_Korp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DataChart_Korp.Location = new System.Drawing.Point(14, 96);
            this.label_DataChart_Korp.Name = "label_DataChart_Korp";
            this.label_DataChart_Korp.Size = new System.Drawing.Size(100, 24);
            this.label_DataChart_Korp.TabIndex = 59;
            this.label_DataChart_Korp.Text = "Korp";
            // 
            // label_DataChart_Pangkat
            // 
            this.label_DataChart_Pangkat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DataChart_Pangkat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DataChart_Pangkat.Location = new System.Drawing.Point(14, 69);
            this.label_DataChart_Pangkat.Name = "label_DataChart_Pangkat";
            this.label_DataChart_Pangkat.Size = new System.Drawing.Size(100, 24);
            this.label_DataChart_Pangkat.TabIndex = 58;
            this.label_DataChart_Pangkat.Text = "Pangkat\t";
            // 
            // label_DataChart_Nama
            // 
            this.label_DataChart_Nama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_DataChart_Nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DataChart_Nama.Location = new System.Drawing.Point(14, 42);
            this.label_DataChart_Nama.Name = "label_DataChart_Nama";
            this.label_DataChart_Nama.Size = new System.Drawing.Size(100, 24);
            this.label_DataChart_Nama.TabIndex = 57;
            this.label_DataChart_Nama.Text = "Nama\t";
            // 
            // cartesianChart_DataChart
            // 
            this.cartesianChart_DataChart.BackColor = System.Drawing.Color.White;
            this.cartesianChart_DataChart.Location = new System.Drawing.Point(3, 158);
            this.cartesianChart_DataChart.Name = "cartesianChart_DataChart";
            this.cartesianChart_DataChart.Size = new System.Drawing.Size(1286, 456);
            this.cartesianChart_DataChart.TabIndex = 56;
            this.cartesianChart_DataChart.Text = "cartesianChart1";
            // 
            // tabSolusi
            // 
            this.tabSolusi.AutoScroll = true;
            this.tabSolusi.Controls.Add(this.button_Solusi_Print);
            this.tabSolusi.Controls.Add(this.textBox_Solusi_Pangkat);
            this.tabSolusi.Controls.Add(this.textBox_Solusi_Korp);
            this.tabSolusi.Controls.Add(this.label14);
            this.tabSolusi.Controls.Add(this.textBox_Solusi_NRP);
            this.tabSolusi.Controls.Add(this.textBox_Solusi_Nama);
            this.tabSolusi.Controls.Add(this.label15);
            this.tabSolusi.Controls.Add(this.label16);
            this.tabSolusi.Controls.Add(this.label17);
            this.tabSolusi.Controls.Add(this.label_Solusi_NRP);
            this.tabSolusi.Controls.Add(this.label_Solusi_Korp);
            this.tabSolusi.Controls.Add(this.label_Solusi_Pangkat);
            this.tabSolusi.Controls.Add(this.label_Solusi_Nama);
            this.tabSolusi.Controls.Add(this.dataGridView_Solusi);
            this.tabSolusi.Location = new System.Drawing.Point(4, 25);
            this.tabSolusi.Name = "tabSolusi";
            this.tabSolusi.Padding = new System.Windows.Forms.Padding(3);
            this.tabSolusi.Size = new System.Drawing.Size(1318, 634);
            this.tabSolusi.TabIndex = 4;
            this.tabSolusi.Text = "Solusi";
            this.tabSolusi.UseVisualStyleBackColor = true;
            // 
            // button_Solusi_Print
            // 
            this.button_Solusi_Print.Location = new System.Drawing.Point(125, 133);
            this.button_Solusi_Print.Name = "button_Solusi_Print";
            this.button_Solusi_Print.Size = new System.Drawing.Size(100, 23);
            this.button_Solusi_Print.TabIndex = 67;
            this.button_Solusi_Print.Text = "Print";
            this.button_Solusi_Print.UseVisualStyleBackColor = true;
            this.button_Solusi_Print.Click += new System.EventHandler(this.button_Solusi_Print_Click);
            // 
            // textBox_Solusi_Pangkat
            // 
            this.textBox_Solusi_Pangkat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_Solusi_Pangkat.Location = new System.Drawing.Point(125, 83);
            this.textBox_Solusi_Pangkat.Name = "textBox_Solusi_Pangkat";
            this.textBox_Solusi_Pangkat.ReadOnly = true;
            this.textBox_Solusi_Pangkat.Size = new System.Drawing.Size(100, 20);
            this.textBox_Solusi_Pangkat.TabIndex = 66;
            // 
            // textBox_Solusi_Korp
            // 
            this.textBox_Solusi_Korp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_Solusi_Korp.Location = new System.Drawing.Point(125, 109);
            this.textBox_Solusi_Korp.Name = "textBox_Solusi_Korp";
            this.textBox_Solusi_Korp.ReadOnly = true;
            this.textBox_Solusi_Korp.Size = new System.Drawing.Size(100, 20);
            this.textBox_Solusi_Korp.TabIndex = 65;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(104, 45);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 24);
            this.label14.TabIndex = 64;
            this.label14.Text = ":";
            // 
            // textBox_Solusi_NRP
            // 
            this.textBox_Solusi_NRP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_Solusi_NRP.Location = new System.Drawing.Point(125, 26);
            this.textBox_Solusi_NRP.Name = "textBox_Solusi_NRP";
            this.textBox_Solusi_NRP.Size = new System.Drawing.Size(100, 20);
            this.textBox_Solusi_NRP.TabIndex = 63;
            // 
            // textBox_Solusi_Nama
            // 
            this.textBox_Solusi_Nama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_Solusi_Nama.Location = new System.Drawing.Point(125, 54);
            this.textBox_Solusi_Nama.Name = "textBox_Solusi_Nama";
            this.textBox_Solusi_Nama.Size = new System.Drawing.Size(100, 20);
            this.textBox_Solusi_Nama.TabIndex = 62;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(104, 104);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 24);
            this.label15.TabIndex = 61;
            this.label15.Text = ":";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(104, 77);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 24);
            this.label16.TabIndex = 60;
            this.label16.Text = ":";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(104, 21);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 24);
            this.label17.TabIndex = 59;
            this.label17.Text = ":";
            // 
            // label_Solusi_NRP
            // 
            this.label_Solusi_NRP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Solusi_NRP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Solusi_NRP.Location = new System.Drawing.Point(16, 26);
            this.label_Solusi_NRP.Name = "label_Solusi_NRP";
            this.label_Solusi_NRP.Size = new System.Drawing.Size(100, 24);
            this.label_Solusi_NRP.TabIndex = 58;
            this.label_Solusi_NRP.Text = "NRP";
            // 
            // label_Solusi_Korp
            // 
            this.label_Solusi_Korp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Solusi_Korp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Solusi_Korp.Location = new System.Drawing.Point(16, 104);
            this.label_Solusi_Korp.Name = "label_Solusi_Korp";
            this.label_Solusi_Korp.Size = new System.Drawing.Size(100, 24);
            this.label_Solusi_Korp.TabIndex = 57;
            this.label_Solusi_Korp.Text = "Korp";
            // 
            // label_Solusi_Pangkat
            // 
            this.label_Solusi_Pangkat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Solusi_Pangkat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Solusi_Pangkat.Location = new System.Drawing.Point(16, 77);
            this.label_Solusi_Pangkat.Name = "label_Solusi_Pangkat";
            this.label_Solusi_Pangkat.Size = new System.Drawing.Size(100, 24);
            this.label_Solusi_Pangkat.TabIndex = 56;
            this.label_Solusi_Pangkat.Text = "Pangkat\t";
            // 
            // label_Solusi_Nama
            // 
            this.label_Solusi_Nama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Solusi_Nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Solusi_Nama.Location = new System.Drawing.Point(16, 50);
            this.label_Solusi_Nama.Name = "label_Solusi_Nama";
            this.label_Solusi_Nama.Size = new System.Drawing.Size(100, 24);
            this.label_Solusi_Nama.TabIndex = 55;
            this.label_Solusi_Nama.Text = "Nama\t";
            // 
            // dataGridView_Solusi
            // 
            this.dataGridView_Solusi.AllowUserToAddRows = false;
            this.dataGridView_Solusi.AllowUserToDeleteRows = false;
            this.dataGridView_Solusi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Solusi.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_Solusi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Solusi.Location = new System.Drawing.Point(6, 162);
            this.dataGridView_Solusi.Name = "dataGridView_Solusi";
            this.dataGridView_Solusi.Size = new System.Drawing.Size(1286, 451);
            this.dataGridView_Solusi.TabIndex = 54;
            // 
            // comboBox_BaudRate
            // 
            this.comboBox_BaudRate.FormattingEnabled = true;
            this.comboBox_BaudRate.Items.AddRange(new object[] {
            "4800",
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "56000",
            "57600",
            "115200",
            "128000",
            "256000"});
            this.comboBox_BaudRate.Location = new System.Drawing.Point(136, 697);
            this.comboBox_BaudRate.Name = "comboBox_BaudRate";
            this.comboBox_BaudRate.Size = new System.Drawing.Size(79, 21);
            this.comboBox_BaudRate.TabIndex = 27;
            this.comboBox_BaudRate.SelectedIndexChanged += new System.EventHandler(this.BaudRate_select);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(221, 698);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 17);
            this.label8.TabIndex = 26;
            this.label8.Text = "Baud";
            // 
            // com_refresh
            // 
            this.com_refresh.Location = new System.Drawing.Point(95, 695);
            this.com_refresh.Name = "com_refresh";
            this.com_refresh.Size = new System.Drawing.Size(25, 23);
            this.com_refresh.TabIndex = 24;
            this.com_refresh.Text = "R";
            this.com_refresh.UseVisualStyleBackColor = true;
            this.com_refresh.Click += new System.EventHandler(this.com_refresh_Click);
            // 
            // comboBox_ComPort
            // 
            this.comboBox_ComPort.FormattingEnabled = true;
            this.comboBox_ComPort.Location = new System.Drawing.Point(12, 697);
            this.comboBox_ComPort.Name = "comboBox_ComPort";
            this.comboBox_ComPort.Size = new System.Drawing.Size(79, 21);
            this.comboBox_ComPort.TabIndex = 23;
            // 
            // button_ComOpenClose
            // 
            this.button_ComOpenClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ComOpenClose.Location = new System.Drawing.Point(288, 695);
            this.button_ComOpenClose.Name = "button_ComOpenClose";
            this.button_ComOpenClose.Size = new System.Drawing.Size(108, 23);
            this.button_ComOpenClose.TabIndex = 22;
            this.button_ComOpenClose.Text = "Connect";
            this.button_ComOpenClose.UseVisualStyleBackColor = true;
            this.button_ComOpenClose.Click += new System.EventHandler(this.button_ComOpenClose_Click);
            // 
            // serialPort
            // 
            this.serialPort.PortName = "COM21";
            this.serialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort_DataReceived);
            // 
            // printDocument_IMT
            // 
            this.printDocument_IMT.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_IMT_PrintPage);
            // 
            // printPreviewDialog_IMT
            // 
            this.printPreviewDialog_IMT.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_IMT.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_IMT.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog_IMT.Document = this.printDocument_IMT;
            this.printPreviewDialog_IMT.Enabled = true;
            this.printPreviewDialog_IMT.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog_IMT.Icon")));
            this.printPreviewDialog_IMT.Name = "printPreviewDialog_IMT";
            this.printPreviewDialog_IMT.Visible = false;
            // 
            // printDocument_DataTable
            // 
            this.printDocument_DataTable.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_DataTable_PrintPage);
            // 
            // printPreviewDialog_DataTable
            // 
            this.printPreviewDialog_DataTable.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_DataTable.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_DataTable.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog_DataTable.Document = this.printDocument_DataTable;
            this.printPreviewDialog_DataTable.Enabled = true;
            this.printPreviewDialog_DataTable.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog_DataTable.Icon")));
            this.printPreviewDialog_DataTable.Name = "printPreviewDialog_IMT";
            this.printPreviewDialog_DataTable.Visible = false;
            // 
            // printPreviewDialog_DataIndividual
            // 
            this.printPreviewDialog_DataIndividual.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_DataIndividual.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_DataIndividual.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog_DataIndividual.Document = this.printDocument_DataIndividual;
            this.printPreviewDialog_DataIndividual.Enabled = true;
            this.printPreviewDialog_DataIndividual.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog_DataIndividual.Icon")));
            this.printPreviewDialog_DataIndividual.Name = "printPreviewDialog_IMT";
            this.printPreviewDialog_DataIndividual.Visible = false;
            // 
            // printDocument_DataIndividual
            // 
            this.printDocument_DataIndividual.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_DataIndividual_PrintPage);
            // 
            // printDocument_DataChart
            // 
            this.printDocument_DataChart.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_DataChart_PrintPage);
            // 
            // printPreviewDialog_DataChart
            // 
            this.printPreviewDialog_DataChart.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_DataChart.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_DataChart.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog_DataChart.Document = this.printDocument_DataChart;
            this.printPreviewDialog_DataChart.Enabled = true;
            this.printPreviewDialog_DataChart.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog_DataChart.Icon")));
            this.printPreviewDialog_DataChart.Name = "printPreviewDialog_IMT";
            this.printPreviewDialog_DataChart.Visible = false;
            // 
            // printDocument_solusi
            // 
            this.printDocument_solusi.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_solusi_PrintPage);
            // 
            // printPreviewDialog_solusi
            // 
            this.printPreviewDialog_solusi.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_solusi.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_solusi.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog_solusi.Document = this.printDocument_solusi;
            this.printPreviewDialog_solusi.Enabled = true;
            this.printPreviewDialog_solusi.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog_solusi.Icon")));
            this.printPreviewDialog_solusi.Name = "printPreviewDialog_IMT";
            this.printPreviewDialog_solusi.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(418, 696);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(141, 20);
            this.textBox1.TabIndex = 28;
            // 
            // button_login
            // 
            this.button_login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_login.Location = new System.Drawing.Point(1224, 14);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(108, 23);
            this.button_login.TabIndex = 29;
            this.button_login.Text = "Login Admin";
            this.button_login.UseVisualStyleBackColor = true;
            this.button_login.Click += new System.EventHandler(this.button_login_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.comboBox_ComPort);
            this.Controls.Add(this.button_ComOpenClose);
            this.Controls.Add(this.com_refresh);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBox_BaudRate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aplikasi Penentuan Index Masa Tubuh";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabIMT.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox_IMT_Gauge.ResumeLayout(false);
            this.groupBox_IMT_Gauge.PerformLayout();
            this.tabData.ResumeLayout(false);
            this.tabData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DataTbaleIMT_Public)).EndInit();
            this.tab_DataIndividual.ResumeLayout(false);
            this.tab_DataIndividual.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DataIndividual)).EndInit();
            this.tabI_DataChart.ResumeLayout(false);
            this.tabI_DataChart.PerformLayout();
            this.tabSolusi.ResumeLayout(false);
            this.tabSolusi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Solusi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabIMT;
        private System.Windows.Forms.TabPage tabData;
        private System.Windows.Forms.TabPage tab_DataIndividual;
        private System.Windows.Forms.TabPage tabI_DataChart;
        private System.Windows.Forms.TabPage tabSolusi;
        private System.Windows.Forms.ComboBox comboBox_BaudRate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button com_refresh;
        private System.Windows.Forms.ComboBox comboBox_ComPort;
        private System.Windows.Forms.Button button_ComOpenClose;
        private System.IO.Ports.SerialPort serialPort;
        private System.Windows.Forms.DataGridView dataGridView_DataTbaleIMT_Public;
        private System.Windows.Forms.TextBox textBox_DataTable_search;
        private System.Windows.Forms.DataGridView dataGridView_DataIndividual;
        private System.Windows.Forms.TextBox textBox_DataChart_Pangkat;
        private System.Windows.Forms.TextBox textBox_DataChart_Korps;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_DataChart_NRP;
        private System.Windows.Forms.TextBox textBox_DataChart_Nama;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_DataChart_NRP;
        private System.Windows.Forms.Label label_DataChart_Korp;
        private System.Windows.Forms.Label label_DataChart_Pangkat;
        private System.Windows.Forms.Label label_DataChart_Nama;
        private LiveCharts.WinForms.CartesianChart cartesianChart_DataChart;
        private System.Windows.Forms.TextBox textBox_DataIndividual_Pangkat;
        private System.Windows.Forms.TextBox textBox_DataIndividual_Korps;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_DataIndividual_NRP;
        private System.Windows.Forms.TextBox textBox_DataIndividual_Nama;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label_DataIndividual_NRP;
        private System.Windows.Forms.Label label_DataIndividual_Korp;
        private System.Windows.Forms.Label label_DataIndividual_Pangkat;
        private System.Windows.Forms.Label label_DataIndividual_Nama;
        private System.Windows.Forms.TextBox textBox_Solusi_Pangkat;
        private System.Windows.Forms.TextBox textBox_Solusi_Korp;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox_Solusi_NRP;
        private System.Windows.Forms.TextBox textBox_Solusi_Nama;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label_Solusi_NRP;
        private System.Windows.Forms.Label label_Solusi_Korp;
        private System.Windows.Forms.Label label_Solusi_Pangkat;
        private System.Windows.Forms.Label label_Solusi_Nama;
        private System.Windows.Forms.DataGridView dataGridView_Solusi;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label_judul;
        private System.Windows.Forms.Button button_GetData;
        private System.Windows.Forms.Label label_beratDiubah;
        private System.Windows.Forms.TextBox textBox_IMT_toBeratIdeal;
        private System.Windows.Forms.TextBox textBox_IMT_Korps;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_IMT_tinggi;
        private System.Windows.Forms.Label label_IMT_Tinggi;
        private System.Windows.Forms.GroupBox groupBox_IMT_Gauge;
        private System.Windows.Forms.Label label_IMT_value;
        private System.Windows.Forms.TextBox textBox_IMT_value;
        private System.Windows.Forms.AGauge aGauge_IMT_IMT;
        private System.Windows.Forms.Button button_IMT_simpan;
        private System.Windows.Forms.Label label_IMT_Status;
        private System.Windows.Forms.Button button_IMT_Hapus;
        private System.Windows.Forms.TextBox textBox_IMT_Status;
        public System.Windows.Forms.TextBox textBox_IMT_NRP;
        private System.Windows.Forms.ComboBox comboBox_IMT_Pangkat;
        private System.Windows.Forms.TextBox textBox_IMT_Nama;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_IMT_Nrp;
        private System.Windows.Forms.Label label_IMT_Korp;
        private System.Windows.Forms.Label label_IMT_Pangkat;
        private System.Windows.Forms.Label label_IMT_nama;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox_IMT_berat;
        private System.Windows.Forms.Label label_IMT_Berat;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button_IMT_print;
        private System.Drawing.Printing.PrintDocument printDocument_IMT;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog_IMT;
        private System.Windows.Forms.Button button_DataTable_Print;
        private System.Drawing.Printing.PrintDocument printDocument_DataTable;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog_DataTable;
        private System.Windows.Forms.Button button_DataIndividual_Print;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog_DataIndividual;
        private System.Drawing.Printing.PrintDocument printDocument_DataIndividual;
        private System.Windows.Forms.Button button_DataChart_Print;
        private System.Drawing.Printing.PrintDocument printDocument_DataChart;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog_DataChart;
        private System.Windows.Forms.Button button_Solusi_Print;
        private System.Drawing.Printing.PrintDocument printDocument_solusi;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog_solusi;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.Button button_DataTable_export;
        private System.Windows.Forms.AGauge aGauge_IMT_berat_badan;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label22;
        private LiveCharts.WinForms.CartesianChart cartesianChart_IMT_tinggi;
        private System.Windows.Forms.DateTimePicker dateTimePicker_IMT;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
    }
}

