-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2018 at 03:06 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imt`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_individual`
--

CREATE TABLE `data_individual` (
  `NRP` int(255) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Pangkat` varchar(255) NOT NULL,
  `Korps` varchar(255) NOT NULL,
  `Tanggal Pengambilan` datetime NOT NULL,
  `Tinggi Badan(cm)` int(255) NOT NULL,
  `Berat Badan(Kg)` double NOT NULL,
  `IMT` double NOT NULL,
  `Status` varchar(255) NOT NULL,
  `Berat Yang Harus Diubah(Kg)` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_individual`
--

INSERT INTO `data_individual` (`NRP`, `Nama`, `Pangkat`, `Korps`, `Tanggal Pengambilan`, `Tinggi Badan(cm)`, `Berat Badan(Kg)`, `IMT`, `Status`, `Berat Yang Harus Diubah(Kg)`) VALUES
(100804, 'Iwan Yulianto', 'Serma', 'Ttg', '2018-10-20 09:52:03', 180, 66.34, 20.48, 'Ideal', ''),
(100728, 'Depilia Surya Candra', 'Serma', 'Ttu', '2018-10-22 19:49:29', 171, 51.62, 17.65, 'Underweight', '+9.78 Kg'),
(104687, 'Agus Setiawan', 'Serka', 'Mes', '2018-10-22 19:52:23', 205, 71.42, 17, 'Underweight', '+16.83 Kg');

-- --------------------------------------------------------

--
-- Table structure for table `data_pangkatkorps`
--

CREATE TABLE `data_pangkatkorps` (
  `Nrp` int(255) NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `Pangkat` varchar(30) NOT NULL,
  `Korps` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_pangkatkorps`
--

INSERT INTO `data_pangkatkorps` (`Nrp`, `Nama`, `Pangkat`, `Korps`) VALUES
(100728, 'Depilia Surya Candra', 'Serma', 'Ttu'),
(100804, 'Iwan Yulianto', 'Serma', 'Ttg'),
(104687, 'Agus Setiawan', 'Serka', 'Mes'),
(108022, 'Bayu Wibisono', 'Serka', 'Kom'),
(108152, 'Yudha Dwi Apriyanto', 'Serka', 'Bek'),
(110120, 'Khairul Huda', 'Serka', 'Nav'),
(112651, 'Moch Faturrochman', 'Serka', 'Bek'),
(114045, 'Krisnal Siolangeng', 'Sertu', 'Nav'),
(115158, 'Nirwan Puriyono', 'Sertu', 'Pdk'),
(533894, 'Rizki Agus Leonar', 'Serka ', 'Pas');

-- --------------------------------------------------------

--
-- Table structure for table `data_public`
--

CREATE TABLE `data_public` (
  `NRP` int(255) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Pangkat` varchar(255) NOT NULL,
  `Korps` varchar(255) NOT NULL,
  `Tanggal Terakhir` datetime NOT NULL,
  `Tinggi Badan(cm)` int(255) NOT NULL,
  `Berat Badan(Kg)` float NOT NULL,
  `IMT` float NOT NULL,
  `Status` varchar(255) NOT NULL,
  `Berat Yang Harus Diubah(Kg)` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_public`
--

INSERT INTO `data_public` (`NRP`, `Nama`, `Pangkat`, `Korps`, `Tanggal Terakhir`, `Tinggi Badan(cm)`, `Berat Badan(Kg)`, `IMT`, `Status`, `Berat Yang Harus Diubah(Kg)`) VALUES
(100728, 'Depilia Surya Candra', 'Serma', 'Ttu', '2018-10-22 19:49:29', 171, 51.62, 17.65, 'Underweight', '+9.78 Kg'),
(100804, 'Iwan Yulianto', 'Serma', 'Ttg', '2018-10-20 09:52:03', 180, 66.34, 20.48, 'Ideal', ''),
(104687, 'Agus Setiawan', 'Serka', 'Mes', '2018-10-22 19:52:23', 205, 71.42, 17, 'Underweight', '+16.83 Kg'),
(108022, 'Bayu Wibisono', 'Serka', 'Kom', '0000-00-00 00:00:00', 0, 0, 0, '', ''),
(108152, 'Yudha Dwi Apriyanto', 'Serka', 'Bek', '0000-00-00 00:00:00', 0, 0, 0, '', ''),
(110120, 'Khairul Huda', 'Serka', 'Nav', '0000-00-00 00:00:00', 0, 0, 0, '', ''),
(112651, 'Moch Faturrochman', 'Serka', 'Bek', '0000-00-00 00:00:00', 0, 0, 0, '', ''),
(114045, 'Krisnal Siolangeng', 'Sertu', 'Nav', '0000-00-00 00:00:00', 0, 0, 0, '', ''),
(115158, 'Nirwan Puriyono', 'Sertu', 'Pdk', '0000-00-00 00:00:00', 0, 0, 0, '', ''),
(533894, 'Rizki Agus Leonar', 'Serka ', 'Pas', '0000-00-00 00:00:00', 0, 0, 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `data_tinggiberat`
--

CREATE TABLE `data_tinggiberat` (
  `Nrp` int(255) NOT NULL,
  `Tinggi Badan(cm)` int(255) NOT NULL,
  `Berat Badan(Kg)` float NOT NULL,
  `IMT` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_individual`
--
ALTER TABLE `data_individual`
  ADD KEY `NRP` (`NRP`);

--
-- Indexes for table `data_pangkatkorps`
--
ALTER TABLE `data_pangkatkorps`
  ADD PRIMARY KEY (`Nrp`);

--
-- Indexes for table `data_public`
--
ALTER TABLE `data_public`
  ADD PRIMARY KEY (`NRP`),
  ADD KEY `NRP` (`NRP`),
  ADD KEY `NRP_2` (`NRP`);

--
-- Indexes for table `data_tinggiberat`
--
ALTER TABLE `data_tinggiberat`
  ADD PRIMARY KEY (`Nrp`),
  ADD KEY `Nrp` (`Nrp`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `data_public`
--
ALTER TABLE `data_public`
  ADD CONSTRAINT `data_public_ibfk_1` FOREIGN KEY (`NRP`) REFERENCES `data_pangkatkorps` (`Nrp`);

--
-- Constraints for table `data_tinggiberat`
--
ALTER TABLE `data_tinggiberat`
  ADD CONSTRAINT `data_tinggiberat_ibfk_1` FOREIGN KEY (`Nrp`) REFERENCES `data_pangkatkorps` (`Nrp`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
